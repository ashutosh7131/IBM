## Instructions

- [README](https://git.homeoffice.anfcorp.com/integration-modernization/di.es.service.spring.jsonschema/-/blob/master/README.md)

## Example code

- [Producer example code](https://git.homeoffice.anfcorp.com/integration-modernization/di.es.sample.producer.spring.jsonschema)
- [Consumer example code](https://git.homeoffice.anfcorp.com/integration-modernization/di.es.sample.consumer.spring.jsonschema)
