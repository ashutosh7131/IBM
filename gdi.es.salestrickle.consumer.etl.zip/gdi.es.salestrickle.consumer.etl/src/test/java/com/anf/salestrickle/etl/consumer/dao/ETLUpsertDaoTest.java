package com.anf.salestrickle.etl.consumer.dao;

import com.anf.logservice.LoggingService;
import com.anf.salestrickle.etl.consumer.model.kafka.SalesTransactions;
import com.anf.salestrickle.etl.consumer.model.tables.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.anf.salestrickle.etl.consumer.data.Constants.*;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@ExtendWith(MockitoExtension.class)
public class ETLUpsertDaoTest {

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Mock
    private LoggingService loggingService;

    @InjectMocks
    private ETLUpsertDao etlUpsertDao;


    private SalesTransactions getSalesTransactionsFromPath() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(new File("src/test/resources/samplejsons/Sample1.json"), SalesTransactions.class);
    }

    private String getJsonMessage() throws IOException {
        return new String(Files.readAllBytes(Paths.get("src/test/resources/samplejsons/Sample1.json")));
    }

    @Test
    @DisplayName("Should Save All Batch Data")
    void saveAllBatchTest() throws IOException {

        SalesTransactions salesTransactions = getSalesTransactionsFromPath();

        Map<String, Object> map = new HashMap<String, Object>();

        map.put(JSON_MESSAGE_STRING, getJsonMessage());

        map.put(OPERATION_TYPE, INSERT);

        SaleTransactionEntity saleTransactionEntity = new SaleTransactionEntity();
        map.put(SALE_TRANSACTION_ENTITY, saleTransactionEntity);

        CustomerInfoEntity customerInfoEntity = new CustomerInfoEntity();
        map.put(CUSTOMER_INFO_ENTITY, customerInfoEntity);

        List<TenderEntity> tenderEntityList = new ArrayList<TenderEntity>();
        tenderEntityList.add(new TenderEntity());
        map.put(TENDER_ENTITY_LIST, tenderEntityList);

        List<SaleLineItemEntity> saleLineItemEntityList = new ArrayList<SaleLineItemEntity>();
        saleLineItemEntityList.add(new SaleLineItemEntity());
        map.put(SALE_LINE_ITEM_ENTITY_LIST, saleLineItemEntityList);

        List<TaxLineItemEntity> taxLineItemEntityList = new ArrayList<TaxLineItemEntity>();
        taxLineItemEntityList.add(new TaxLineItemEntity());
        map.put(TAX_LINE_ITEM_ENTITY_LIST, taxLineItemEntityList);

        List<DiscountLineItemEntity> discountLineItemEntityList = new ArrayList<DiscountLineItemEntity>();
        discountLineItemEntityList.add(new DiscountLineItemEntity());
        map.put(DISCOUNT_LINE_ITEM_ENTITY_LIST, discountLineItemEntityList);

        assertDoesNotThrow(() -> etlUpsertDao.saveAllBatch(salesTransactions, map));

        map.put(OPERATION_TYPE, UPDATE);

        assertDoesNotThrow(() -> etlUpsertDao.saveAllBatch(salesTransactions, map));
    }
}
