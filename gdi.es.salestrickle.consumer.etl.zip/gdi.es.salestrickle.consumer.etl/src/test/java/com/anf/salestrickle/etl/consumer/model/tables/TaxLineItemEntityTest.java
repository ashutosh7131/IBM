package com.anf.salestrickle.etl.consumer.model.tables;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class TaxLineItemEntityTest {

    @Test
    @DisplayName("Should be able to set the values using the setters and retrieve them using the getters.")
    public void shouldBeAbleToSetTheValuesUsingTheSettersAndRetrieveThemUsingTheGetters() {

        var storeId = "1002";
        var workstationId = "102";
        var businessDate = "2023-02-10";
        var sequenceNumber = "210";
        var lineItemNumber = 5.0;
        var taxLinetype = "TLT";
        var authority = "Authority";
        var amount = "1002";
        var rate = "10.02";
        var name = "ABC";


        var taxLineItemEntity = new TaxLineItemEntity();

        taxLineItemEntity.setStoreId(storeId);
        taxLineItemEntity.setWorkstationId(workstationId);
        taxLineItemEntity.setBusinessDate(businessDate);
        taxLineItemEntity.setSequenceNumber(sequenceNumber);
        taxLineItemEntity.setLineItemNumber(lineItemNumber);
        taxLineItemEntity.setTaxLinetype(taxLinetype);
        taxLineItemEntity.setAuthority(authority);
        taxLineItemEntity.setAmount(amount);
        taxLineItemEntity.setRate(rate);
        taxLineItemEntity.setName(name);

        assertAll(
                () -> assertEquals(storeId, taxLineItemEntity.getStoreId()),
                () -> assertEquals(workstationId, taxLineItemEntity.getWorkstationId()),
                () -> assertEquals(businessDate, taxLineItemEntity.getBusinessDate()),
                () -> assertEquals(sequenceNumber, taxLineItemEntity.getSequenceNumber()),
                () -> assertEquals(lineItemNumber, taxLineItemEntity.getLineItemNumber()),
                () -> assertEquals(taxLinetype, taxLineItemEntity.getTaxLinetype()),
                () -> assertEquals(authority, taxLineItemEntity.getAuthority()),
                () -> assertEquals(amount, taxLineItemEntity.getAmount()),
                () -> assertEquals(rate, taxLineItemEntity.getRate()),
                () -> assertEquals(name, taxLineItemEntity.getName())
        );

    }
}
