package com.anf.salestrickle.etl.consumer.model.kafka;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class AddressInfoTest {

    @InjectMocks
    AddressInfo addressInfo;

    @Test
    @DisplayName("Should be able to set the values using the setters and retrieve them using the getters.")
    void shouldBeAbleToSetTheValuesUsingTheSettersAndRetrieveThemUsingTheGetters() {
        var address1 = "TestAddrss1";
        var address2 = "TestAddrss2";
        var city = "TestCity";
        var state = "TestState";
        var zipCode = "TestZip";
        var zipCodeExt = "Test";
        var country = "US";

        addressInfo.setAddress1(address1);
        addressInfo.setAddress2(address2);
        addressInfo.setCity(city);
        addressInfo.setState(state);
        addressInfo.setZipCode(zipCode);
        addressInfo.setZipCodeExt(zipCodeExt);
        addressInfo.setCountry(country);

        assertAll(
                () -> assertEquals(address1, addressInfo.getAddress1()),
                () -> assertEquals(address2, addressInfo.getAddress2()),
                () -> assertEquals(city, addressInfo.getCity()),
                () -> assertEquals(state, addressInfo.getState()),
                () -> assertEquals(zipCode, addressInfo.getZipCode()),
                () -> assertEquals(zipCodeExt, addressInfo.getZipCodeExt()),
                () -> assertEquals(country, addressInfo.getCountry())
        );
    }
}
