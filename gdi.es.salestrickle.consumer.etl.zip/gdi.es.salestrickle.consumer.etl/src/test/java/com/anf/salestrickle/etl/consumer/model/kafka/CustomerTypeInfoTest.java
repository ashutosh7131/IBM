package com.anf.salestrickle.etl.consumer.model.kafka;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class CustomerTypeInfoTest {
    @Test
    @DisplayName("Should be able to set the values using the setters and retrieve them using the getters.")
    void shouldBeAbleToSetTheValuesUsingTheSettersAndRetrieveThemUsingTheGetters() {
        var loyaltyPartner = "BAZ";
        var lastName = "xyz";
        var firstName = "abc";
        var email = "abc@xyz.com";
        var idType = "545";
        var idSwiped = false;
        var encryptedId = "8765";
        var customerLinkType = "test";
        var customerLinkCode = "123";
        var customerReturnLinkCode = "654";
        var checkForRewardsAccount = false;
        var shipToTaxAreaId = 0;
        var shippingTransportMode = "";
        var shippingDate = new Date();
        var shippingDeliveryTerms = "";
        var shippingOverrideReason = "";
        var eReceiptIndicator = 2;
        var marketingEmailIndicator = 1;
        var customerWebStoreId = "102";

        var model = new CustomerInfoType();

        model.setCustomerLinkType(customerLinkType);
        model.setIdType(idType);
        model.setCustomerLinkCode(customerLinkCode);
        model.setCheckForRewardsAccount(checkForRewardsAccount);
        model.setCustomerReturnLinkCode(customerReturnLinkCode);
        model.setEmail(email);
        model.setEncryptedId(encryptedId);
        model.setEReceiptIndicator(eReceiptIndicator);
        model.setFirstName(firstName);
        model.setLastName(lastName);
        model.setIdSwiped(idSwiped);
        model.setLoyaltyPartner(loyaltyPartner);
        model.setMarketingEmailIndicator(marketingEmailIndicator);
        model.setShipToTaxAreaId(shipToTaxAreaId);

        model.setShippingTransportMode(shippingTransportMode);
        model.setShippingDate(shippingDate);
        model.setShippingDeliveryTerms(shippingDeliveryTerms);
        model.setShippingOverrideReason(shippingOverrideReason);
        model.setCustomerWebStoreId(customerWebStoreId);

        assertAll(
                () -> assertEquals(loyaltyPartner, model.getLoyaltyPartner()),
                () -> assertEquals(firstName, model.getFirstName()),
                () -> assertEquals(lastName, model.getLastName()),
                () -> assertEquals(email, model.getEmail()),
                () -> assertEquals(marketingEmailIndicator, model.getMarketingEmailIndicator()),
                () -> assertEquals(idSwiped, model.getIdSwiped()),
                () -> assertEquals(idType, model.getIdType()),
                () -> assertEquals(shipToTaxAreaId, model.getShipToTaxAreaId()),
                () -> assertEquals(shippingTransportMode, model.getShippingTransportMode()),
                () -> assertEquals(shippingDate, model.getShippingDate()),
                () -> assertEquals(shippingDeliveryTerms, model.getShippingDeliveryTerms()),
                () -> assertEquals(shippingOverrideReason, model.getShippingOverrideReason()),
                () -> assertEquals(customerWebStoreId, model.getCustomerWebStoreId())


        );

    }
}
