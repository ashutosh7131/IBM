package com.anf.salestrickle.etl.consumer.service;

import com.anf.kafkaservicejsonschema.models.Consumer;
import com.anf.kafkaservicejsonschema.models.Producer;
import com.anf.logservice.LoggingService;
import com.anf.salestrickle.etl.consumer.config.AppKafkaConfig;
import com.anf.salestrickle.etl.consumer.model.kafka.SalesTransactions;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.io.File;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@MockitoSettings(strictness = Strictness.LENIENT)
@ExtendWith(MockitoExtension.class)
public class ETLConsumerServiceTest {

    @Mock
    private Consumer<Object> consumer;

    @Mock
    private AppKafkaConfig kafkaProperties;

    @Mock
    private LoggingService loggingService;

    @Mock
    private Producer<SalesTransactions> producer;

    @Mock
    private ETLUpsertService etlUpsertService;

    @InjectMocks
    private ETLConsumerService etlConsumerService;


    private SalesTransactions getSalesTransactionsFromPath() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(new File("src/test/resources/samplejsons/Sample1.json"), SalesTransactions.class);
    }


    @Test
    @DisplayName("Should Read Message")
    void shouldReadMSG() throws Exception {

        SalesTransactions salesTransactions = getSalesTransactionsFromPath();
        assertDoesNotThrow(() -> etlConsumerService.processEvent(salesTransactions));
    }
}
