package com.anf.salestrickle.etl.consumer.model.tables;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class TenderEntityTest {

    @Test
    @DisplayName("Should be able to set the values using the setters and retrieve them using the getters.")
    public void shouldBeAbleToSetTheValuesUsingTheSettersAndRetrieveThemUsingTheGetters() {

        var storeId = "1002";
        var workstationId = "102";
        var businessDate = "2023-02-10";
        var sequenceNumber = "210";
        var tenderNumber = 1.0;
        var tenderAmount = 102.0;
        var accountName = "ANF";
        var tenderType = "TT";
        var tenderTypeId = "TID";
        var cardAuthMethod = "CAM";
        var cardAuthReturnCode = "CAR";
        var cardEntryMode = "CEM";
        var encryptedExpDate = "YYXCVADSCF";
        var encryptedCardNumber = "shj3r54tkHVK";
        var maskedCardNumber = "123XXXXXX789";
        var encryptedCheckRoutingNumber = "ECRN";
        var encryptedCheckAccountNumber = "ECAN";
        var hashedCardNumber = "121345gads135rt";
        var lineItemNumber = Double.valueOf(2);
        var storeCurrencyCode = "USD";
        var tenderExchangeRate = Double.valueOf(10.02);
        var foreignTenderCurrencyCode = "INR";
        var foreignTenderAmount = Double.valueOf(1002);
        var encryptionType = "ET";

        var tenderEntity = new TenderEntity();

        tenderEntity.setStoreId(storeId);
        tenderEntity.setWorkstationId(workstationId);
        tenderEntity.setBusinessDate(businessDate);
        tenderEntity.setSequenceNumber(sequenceNumber);
        tenderEntity.setTenderNumber(tenderNumber);
        tenderEntity.setTenderAmount(tenderAmount);
        tenderEntity.setAccountName(accountName);
        tenderEntity.setTenderType(tenderType);
        tenderEntity.setTenderTypeId(tenderTypeId);
        tenderEntity.setCardAuthMethod(cardAuthMethod);
        tenderEntity.setCardAuthReturnCode(cardAuthReturnCode);
        tenderEntity.setCardEntryMode(cardEntryMode);
        tenderEntity.setEncryptedExpDate(encryptedExpDate);
        tenderEntity.setEncryptedCardNumber(encryptedCardNumber);
        tenderEntity.setMaskedCardNumber(maskedCardNumber);
        tenderEntity.setEncryptedCheckRoutingNumber(encryptedCheckRoutingNumber);
        tenderEntity.setEncryptedCheckAccountNumber(encryptedCheckAccountNumber);
        tenderEntity.setHashedCardNumber(hashedCardNumber);
        tenderEntity.setLineItemNumber(lineItemNumber);
        tenderEntity.setStoreCurrencyCode(storeCurrencyCode);
        tenderEntity.setTenderExchangeRate(tenderExchangeRate);
        tenderEntity.setForeignTenderCurrencyCode(foreignTenderCurrencyCode);
        tenderEntity.setForeignTenderAmount(foreignTenderAmount);
        tenderEntity.setEncryptionType(encryptionType);

        assertAll(
                () -> assertEquals(storeId, tenderEntity.getStoreId()),
                () -> assertEquals(workstationId, tenderEntity.getWorkstationId()),
                () -> assertEquals(businessDate, tenderEntity.getBusinessDate()),
                () -> assertEquals(sequenceNumber, tenderEntity.getSequenceNumber()),
                () -> assertEquals(tenderNumber, tenderEntity.getTenderNumber()),
                () -> assertEquals(tenderAmount, tenderEntity.getTenderAmount()),
                () -> assertEquals(accountName, tenderEntity.getAccountName()),
                () -> assertEquals(tenderType, tenderEntity.getTenderType()),
                () -> assertEquals(tenderTypeId, tenderEntity.getTenderTypeId()),
                () -> assertEquals(cardAuthMethod, tenderEntity.getCardAuthMethod()),
                () -> assertEquals(cardAuthReturnCode, tenderEntity.getCardAuthReturnCode()),
                () -> assertEquals(cardEntryMode, tenderEntity.getCardEntryMode()),
                () -> assertEquals(encryptedExpDate, tenderEntity.getEncryptedExpDate()),
                () -> assertEquals(encryptedCardNumber, tenderEntity.getEncryptedCardNumber()),
                () -> assertEquals(maskedCardNumber, tenderEntity.getMaskedCardNumber()),
                () -> assertEquals(encryptedCheckRoutingNumber, tenderEntity.getEncryptedCheckRoutingNumber()),
                () -> assertEquals(encryptedCheckAccountNumber, tenderEntity.getEncryptedCheckAccountNumber()),
                () -> assertEquals(hashedCardNumber, tenderEntity.getHashedCardNumber()),
                () -> assertEquals(lineItemNumber, tenderEntity.getLineItemNumber()),
                () -> assertEquals(storeCurrencyCode, tenderEntity.getStoreCurrencyCode()),
                () -> assertEquals(tenderExchangeRate, tenderEntity.getTenderExchangeRate()),
                () -> assertEquals(foreignTenderCurrencyCode, tenderEntity.getForeignTenderCurrencyCode()),
                () -> assertEquals(foreignTenderAmount, tenderEntity.getForeignTenderAmount()),
                () -> assertEquals(encryptionType, tenderEntity.getEncryptionType())
        );


    }
}
