package com.anf.salestrickle.etl.consumer.beans;


import com.anf.kafkaservicejsonschema.KafkaServiceJsonSchema;
import com.anf.kafkaservicejsonschema.models.Producer;
import com.anf.salestrickle.etl.consumer.config.AppKafkaConfig;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class KafkaProducerBeansTests {

    @Mock
    AppKafkaConfig appKafkaConfig;

    @Mock
    KafkaServiceJsonSchema kafkaService;

    @InjectMocks
    KafkaProducerBeans kafkaProducerBean;

    @SuppressWarnings(value = "unchecked")
    @Test
    @DisplayName("Should return a Dlt Producer object when calling producer method.")
    void shouldReturnADltProducerObjectWhenCallingProducerMethod() throws Exception {

        var dltTopicName = "example-dlt-topic-name";
        when(this.appKafkaConfig.getDltTopic()).thenReturn(dltTopicName);
        when(this.kafkaService.getProducer(dltTopicName)).thenReturn(mock(Producer.class));

        var producer = this.kafkaProducerBean.getDltProducer();
        assertAll(
                () -> assertNotNull(producer),
                () -> verify(this.appKafkaConfig, times(1)).getDltTopic(),
                () -> verify(this.kafkaService, times(1)).getProducer(dltTopicName)
        );
    }
    
    @SuppressWarnings(value = "unchecked")
    @Test
    @DisplayName("Should return a Producer object when calling producer method.")
    void shouldReturnAProducerObjectWhenCallingProducerMethod() throws Exception {

        var topicName = "example-producer-topic-name";
        when(this.appKafkaConfig.getTopic()).thenReturn(topicName);
        when(this.kafkaService.getProducer(topicName)).thenReturn(mock(Producer.class));

        var producer = this.kafkaProducerBean.getDltProducer();
        assertAll(
                () -> assertNotNull(producer),
                () -> verify(this.appKafkaConfig, times(1)).getTopic(),
                () -> verify(this.kafkaService, times(1)).getProducer(topicName)
        );
    }
}
