package com.anf.salestrickle.etl.consumer.model.tables;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class SaleLineItemEntityTest {

    @Test
    @DisplayName("Should be able to set the values using the setters and retrieve them using the getters.")
    public void shouldBeAbleToSetTheValuesUsingTheSettersAndRetrieveThemUsingTheGetters() {

        var storeId = "1002";
        var workstationId = "102";
        var businessDate = "2023-02-10";
        var sequenceNumber = "210";
        var lineItemNumber = 1.0;
        var itemId = "12";
        var origItemId = "12";
        var quantity = 12.0;
        var nonMerch = 'Y';
        var ticketAmount = 1002.0;
        var discountAmount = 102.0;
        var sellAmount = 1002.0;
        var taxAmount = 210.0;
        var voided = 'Y';
        var giftReceiptPrinted = 'Y';
        var maskedGiftCardId = "12345";
        var taxGroupId = "10";
        var origStoreId = "1002";
        var origWorkstationId = "102";
        var origBusinessDay = "2023-02-10";
        var origSequenceNumber = Double.valueOf(210);
        var origLineItemNumber = Double.valueOf(2);
        var origReceiptEntryMethod = "OREM";
        var origReceiptType = "ORT";
        var entryMethod = "A";
        var returnReasonCode = "RRC";
        var priceOverride = 'Y';
        var priceOverrideReasonCode = "102";
        var taxOverride = 'Y';
        var giftCardRequestType = "GCRT";
        var encryptedGiftCardNumber = "12345";
        var shippingIntrastatCode = "102";
        var shippingMass = "12";
        var shippingCountryOfOrigin = "SCOO";
        var shippingFromCountry = "SFC";
        var extendedAmount = Double.valueOf(0.0);
        var originateStockOutReasonCode = Double.valueOf(0.0);
        var priceTypeCode = Double.valueOf(1.0);
        var fulfillStoreID = "1002";
        var omniCode = "OC";
        var pickupStoreId = "1002";
        var fulfillStoreAssociateId = "1234567890";
        var demStoreId = "1002";
        var demWorkstationId = "102";
        var demSequenceNumber = "210";
        var demBusinessDate = "2023-02-10";

        var saleLineItemEntity = new SaleLineItemEntity();

        saleLineItemEntity.setStoreId(storeId);
        saleLineItemEntity.setWorkstationId(workstationId);
        saleLineItemEntity.setBusinessDate(businessDate);
        saleLineItemEntity.setSequenceNumber(sequenceNumber);
        saleLineItemEntity.setLineItemNumber(lineItemNumber);
        saleLineItemEntity.setItemId(itemId);
        saleLineItemEntity.setOrigItemId(origItemId);
        saleLineItemEntity.setQuantity(quantity);
        saleLineItemEntity.setNonMerch(nonMerch);
        saleLineItemEntity.setTicketAmount(ticketAmount);
        saleLineItemEntity.setDiscountAmount(discountAmount);
        saleLineItemEntity.setSellAmount(sellAmount);
        saleLineItemEntity.setTaxAmount(taxAmount);
        saleLineItemEntity.setVoided(voided);
        saleLineItemEntity.setGiftReceiptPrinted(giftReceiptPrinted);
        saleLineItemEntity.setMaskedGiftCardId(maskedGiftCardId);
        saleLineItemEntity.setTaxGroupId(taxGroupId);
        saleLineItemEntity.setOrigStoreId(origStoreId);
        saleLineItemEntity.setOrigWorkstationId(origWorkstationId);
        saleLineItemEntity.setOrigBusinessDay(origBusinessDay);
        saleLineItemEntity.setOrigSequenceNumber(origSequenceNumber);
        saleLineItemEntity.setOrigLineItemNumber(origLineItemNumber);
        saleLineItemEntity.setOrigReceiptEntryMethod(origReceiptEntryMethod);
        saleLineItemEntity.setOrigReceiptType(origReceiptType);
        saleLineItemEntity.setEntryMethod(entryMethod);
        saleLineItemEntity.setReturnReasonCode(returnReasonCode);
        saleLineItemEntity.setPriceOverride(priceOverride);
        saleLineItemEntity.setPriceOverrideReasonCode(priceOverrideReasonCode);
        saleLineItemEntity.setTaxOverride(taxOverride);
        saleLineItemEntity.setGiftCardRequestType(giftCardRequestType);
        saleLineItemEntity.setEncryptedGiftCardNumber(encryptedGiftCardNumber);
        saleLineItemEntity.setShippingIntrastatCode(shippingIntrastatCode);
        saleLineItemEntity.setShippingMass(shippingMass);
        saleLineItemEntity.setShippingCountryOfOrigin(shippingCountryOfOrigin);
        saleLineItemEntity.setShippingFromCountry(shippingFromCountry);
        saleLineItemEntity.setExtendedAmount(extendedAmount);
        saleLineItemEntity.setOriginateStockOutReasonCode(originateStockOutReasonCode);
        saleLineItemEntity.setPriceTypeCode(priceTypeCode);
        saleLineItemEntity.setFulfillStoreID(fulfillStoreID);
        saleLineItemEntity.setOmniCode(omniCode);
        saleLineItemEntity.setPickupStoreId(pickupStoreId);
        saleLineItemEntity.setFulfillStoreAssociateId(fulfillStoreAssociateId);
        saleLineItemEntity.setDemStoreId(demStoreId);
        saleLineItemEntity.setDemWorkstationId(demWorkstationId);
        saleLineItemEntity.setDemSequenceNumber(demSequenceNumber);
        saleLineItemEntity.setDemBusinessDate(demBusinessDate);

        assertAll(

                () -> assertEquals(storeId, saleLineItemEntity.getStoreId()),
                () -> assertEquals(workstationId, saleLineItemEntity.getWorkstationId()),
                () -> assertEquals(businessDate, saleLineItemEntity.getBusinessDate()),
                () -> assertEquals(sequenceNumber, saleLineItemEntity.getSequenceNumber()),
                () -> assertEquals(lineItemNumber, saleLineItemEntity.getLineItemNumber()),
                () -> assertEquals(itemId, saleLineItemEntity.getItemId()),
                () -> assertEquals(origItemId, saleLineItemEntity.getOrigItemId()),
                () -> assertEquals(quantity, saleLineItemEntity.getQuantity()),
                () -> assertEquals(nonMerch, saleLineItemEntity.getNonMerch()),
                () -> assertEquals(ticketAmount, saleLineItemEntity.getTicketAmount()),
                () -> assertEquals(discountAmount, saleLineItemEntity.getDiscountAmount()),
                () -> assertEquals(sellAmount, saleLineItemEntity.getSellAmount()),
                () -> assertEquals(taxAmount, saleLineItemEntity.getTaxAmount()),
                () -> assertEquals(voided, saleLineItemEntity.getVoided()),
                () -> assertEquals(giftReceiptPrinted, saleLineItemEntity.getGiftReceiptPrinted()),
                () -> assertEquals(maskedGiftCardId, saleLineItemEntity.getMaskedGiftCardId()),
                () -> assertEquals(taxGroupId, saleLineItemEntity.getTaxGroupId()),
                () -> assertEquals(origStoreId, saleLineItemEntity.getOrigStoreId()),
                () -> assertEquals(origWorkstationId, saleLineItemEntity.getOrigWorkstationId()),
                () -> assertEquals(origBusinessDay, saleLineItemEntity.getOrigBusinessDay()),
                () -> assertEquals(origSequenceNumber, saleLineItemEntity.getOrigSequenceNumber()),
                () -> assertEquals(origLineItemNumber, saleLineItemEntity.getOrigLineItemNumber()),
                () -> assertEquals(origReceiptEntryMethod, saleLineItemEntity.getOrigReceiptEntryMethod()),
                () -> assertEquals(origReceiptType, saleLineItemEntity.getOrigReceiptType()),
                () -> assertEquals(entryMethod, saleLineItemEntity.getEntryMethod()),
                () -> assertEquals(returnReasonCode, saleLineItemEntity.getReturnReasonCode()),
                () -> assertEquals(priceOverride, saleLineItemEntity.getPriceOverride()),
                () -> assertEquals(priceOverrideReasonCode, saleLineItemEntity.getPriceOverrideReasonCode()),
                () -> assertEquals(taxOverride, saleLineItemEntity.getTaxOverride()),
                () -> assertEquals(giftCardRequestType, saleLineItemEntity.getGiftCardRequestType()),
                () -> assertEquals(encryptedGiftCardNumber, saleLineItemEntity.getEncryptedGiftCardNumber()),
                () -> assertEquals(shippingIntrastatCode, saleLineItemEntity.getShippingIntrastatCode()),
                () -> assertEquals(shippingMass, saleLineItemEntity.getShippingMass()),
                () -> assertEquals(shippingCountryOfOrigin, saleLineItemEntity.getShippingCountryOfOrigin()),
                () -> assertEquals(shippingFromCountry, saleLineItemEntity.getShippingFromCountry()),
                () -> assertEquals(extendedAmount, saleLineItemEntity.getExtendedAmount()),
                () -> assertEquals(originateStockOutReasonCode, saleLineItemEntity.getOriginateStockOutReasonCode()),
                () -> assertEquals(priceTypeCode, saleLineItemEntity.getPriceTypeCode()),
                () -> assertEquals(fulfillStoreID, saleLineItemEntity.getFulfillStoreID()),
                () -> assertEquals(omniCode, saleLineItemEntity.getOmniCode()),
                () -> assertEquals(pickupStoreId, saleLineItemEntity.getPickupStoreId()),
                () -> assertEquals(fulfillStoreAssociateId, saleLineItemEntity.getFulfillStoreAssociateId()),
                () -> assertEquals(demStoreId, saleLineItemEntity.getDemStoreId()),
                () -> assertEquals(demWorkstationId, saleLineItemEntity.getDemWorkstationId()),
                () -> assertEquals(demSequenceNumber, saleLineItemEntity.getDemSequenceNumber()),
                () -> assertEquals(demBusinessDate, saleLineItemEntity.getDemBusinessDate())

        );

    }
}
