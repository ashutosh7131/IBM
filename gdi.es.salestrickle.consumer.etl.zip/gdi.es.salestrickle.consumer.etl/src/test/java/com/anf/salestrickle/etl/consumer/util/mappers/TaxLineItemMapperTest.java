package com.anf.salestrickle.etl.consumer.util.mappers;

import com.anf.salestrickle.etl.consumer.model.kafka.SaleLineItemType;
import com.anf.salestrickle.etl.consumer.model.tables.TaxLineItemEntity;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.anf.salestrickle.etl.consumer.data.Constants.SEQUENCE_NUMBER;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;


@ExtendWith(MockitoExtension.class)
//@SpringBootTest

public class TaxLineItemMapperTest {

    @InjectMocks
    private TaxLineItemMapper mapper;

    private SaleLineItemType getSaleLineItemTypeFromPath() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(new File("src/test/resources/samplejsons/Sample2.json"), SaleLineItemType.class);
    }

    @Test
    @DisplayName("Should Able To Map Entities in Map Object")
    public void mapEntities() throws IOException {
        Map<String, Object> map = new HashMap<String, Object>();
        List<TaxLineItemEntity> taxLineItemEntityList = new ArrayList<TaxLineItemEntity>();
        map.put(SEQUENCE_NUMBER, "210");
        SaleLineItemType saleLineItemType = getSaleLineItemTypeFromPath();
        mapper.mapToTaxLineItemEntity(saleLineItemType, map, taxLineItemEntityList);
        assertDoesNotThrow(() -> mapper.mapToTaxLineItemEntity(saleLineItemType, map, taxLineItemEntityList));
    }
}