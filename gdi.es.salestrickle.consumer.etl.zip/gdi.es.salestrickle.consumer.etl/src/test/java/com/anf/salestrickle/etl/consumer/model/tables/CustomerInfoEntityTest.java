package com.anf.salestrickle.etl.consumer.model.tables;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class CustomerInfoEntityTest {


    @Test
    @DisplayName("Should be able to set the values using the setters and retrieve them using the getters.")
    public void shouldBeAbleToSetTheValuesUsingTheSettersAndRetrieveThemUsingTheGetters() {
        var storeId = "1002";
        var workstationId = "102";
        var businessDate = "2023-02-10";
        var sequenceNumber = 210.00d;
        var lastName = "xyz";
        var firstName = "abc";
        var email = "abc@xyz.com";
        var phone = "+1 12345690";
        var address1 = "Test Address1";
        var address2 = "Test Address2";
        var city = "Test City";
        var state = "Test State";
        var zipCode = "12345";
        var zipCodeExt = "12";
        var country = "test country";
        var idType = "545";
        var idSwiped = 'Y';
        var encryptedId = "1234";
        var customerLinkType = "test";
        var customerLinkCode = "11";
        var shipToAddress1 = "Ship Address1";
        var shipToAddress2 = "Ship Address2";
        var shipToCity = "Ship City";
        var shipToState = "Ship to State";
        var shipToZipCode = "12345";
        var shipToZipCodeExt = "45";
        var shipToCountry = "Ship to Country";
        var shipToTaxAreaId = Integer.valueOf(1234);
        var shippingTransportMode = "Road";
        var shippingDate = new Date();
        var shippingDeliveryTerms = "Delivery Terms";
        var eReceiptIndicator = Integer.valueOf(1);
        var marketingEmailIndicator = Integer.valueOf(1);
        var shippingOverrideReason = "NA";


        var customerInfoEntity = new CustomerInfoEntity();

        customerInfoEntity.setStoreId(storeId);
        customerInfoEntity.setWorkstationId(workstationId);
        customerInfoEntity.setBusinessDate(businessDate);
        customerInfoEntity.setSequenceNumber(sequenceNumber);
        customerInfoEntity.setLastName(lastName);
        customerInfoEntity.setFirstName(firstName);
        customerInfoEntity.setEmail(email);
        customerInfoEntity.setPhone(phone);
        customerInfoEntity.setAddress1(address1);
        customerInfoEntity.setAddress2(address2);
        customerInfoEntity.setCity(city);
        customerInfoEntity.setState(state);
        customerInfoEntity.setZipCode(zipCode);
        customerInfoEntity.setZipCodeExt(zipCodeExt);
        customerInfoEntity.setCountry(country);
        customerInfoEntity.setIdType(idType);
        customerInfoEntity.setIdSwiped(idSwiped);
        customerInfoEntity.setEncryptedId(encryptedId);
        customerInfoEntity.setCustomerLinkType(customerLinkType);
        customerInfoEntity.setCustomerLinkCode(customerLinkCode);
        customerInfoEntity.setShipToAddress1(shipToAddress1);
        customerInfoEntity.setShipToAddress2(shipToAddress2);
        customerInfoEntity.setShipToCity(shipToCity);
        customerInfoEntity.setShipToState(shipToState);
        customerInfoEntity.setShipToZipCode(shipToZipCode);
        customerInfoEntity.setShipToZipCodeExt(shipToZipCodeExt);
        customerInfoEntity.setShipToCountry(shipToCountry);
        customerInfoEntity.setShipToTaxAreaId(shipToTaxAreaId);
        customerInfoEntity.setShippingTransportMode(shippingTransportMode);
        customerInfoEntity.setShippingDate(shippingDate);
        customerInfoEntity.setShippingDeliveryTerms(shippingDeliveryTerms);
        customerInfoEntity.setEReceiptIndicator(eReceiptIndicator);
        customerInfoEntity.setMarketingEmailIndicator(marketingEmailIndicator);
        customerInfoEntity.setShippingOverrideReason(shippingOverrideReason);

        assertAll(

                () -> assertEquals(storeId, customerInfoEntity.getStoreId()),
                () -> assertEquals(workstationId, customerInfoEntity.getWorkstationId()),
                () -> assertEquals(businessDate, customerInfoEntity.getBusinessDate()),
                () -> assertEquals(sequenceNumber, customerInfoEntity.getSequenceNumber()),
                () -> assertEquals(lastName, customerInfoEntity.getLastName()),
                () -> assertEquals(firstName, customerInfoEntity.getFirstName()),
                () -> assertEquals(email, customerInfoEntity.getEmail()),
                () -> assertEquals(phone, customerInfoEntity.getPhone()),
                () -> assertEquals(address1, customerInfoEntity.getAddress1()),
                () -> assertEquals(address2, customerInfoEntity.getAddress2()),
                () -> assertEquals(city, customerInfoEntity.getCity()),
                () -> assertEquals(state, customerInfoEntity.getState()),
                () -> assertEquals(zipCode, customerInfoEntity.getZipCode()),
                () -> assertEquals(zipCodeExt, customerInfoEntity.getZipCodeExt()),
                () -> assertEquals(country, customerInfoEntity.getCountry()),
                () -> assertEquals(idType, customerInfoEntity.getIdType()),
                () -> assertEquals(idSwiped, customerInfoEntity.getIdSwiped()),
                () -> assertEquals(encryptedId, customerInfoEntity.getEncryptedId()),
                () -> assertEquals(customerLinkType, customerInfoEntity.getCustomerLinkType()),
                () -> assertEquals(customerLinkCode, customerInfoEntity.getCustomerLinkCode()),
                () -> assertEquals(shipToAddress1, customerInfoEntity.getShipToAddress1()),
                () -> assertEquals(shipToAddress2, customerInfoEntity.getShipToAddress2()),
                () -> assertEquals(shipToCity, customerInfoEntity.getShipToCity()),
                () -> assertEquals(shipToState, customerInfoEntity.getShipToState()),
                () -> assertEquals(shipToZipCode, customerInfoEntity.getShipToZipCode()),
                () -> assertEquals(shipToZipCodeExt, customerInfoEntity.getShipToZipCodeExt()),
                () -> assertEquals(shipToCountry, customerInfoEntity.getShipToCountry()),
                () -> assertEquals(shipToTaxAreaId, customerInfoEntity.getShipToTaxAreaId()),
                () -> assertEquals(shippingTransportMode, customerInfoEntity.getShippingTransportMode()),
                () -> assertEquals(shippingDate, customerInfoEntity.getShippingDate()),
                () -> assertEquals(shippingDeliveryTerms, customerInfoEntity.getShippingDeliveryTerms()),
                () -> assertEquals(eReceiptIndicator, customerInfoEntity.getEReceiptIndicator()),
                () -> assertEquals(marketingEmailIndicator, customerInfoEntity.getMarketingEmailIndicator()),
                () -> assertEquals(shippingOverrideReason, customerInfoEntity.getShippingOverrideReason())

        );

    }

}
