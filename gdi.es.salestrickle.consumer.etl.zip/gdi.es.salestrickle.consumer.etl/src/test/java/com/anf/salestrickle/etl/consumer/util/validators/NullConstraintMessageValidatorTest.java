package com.anf.salestrickle.etl.consumer.util.validators;

import com.anf.salestrickle.etl.consumer.model.kafka.SaleTransactionMessage;
import com.anf.salestrickle.etl.consumer.model.kafka.SalesTransactions;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.io.IOException;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
public class NullConstraintMessageValidatorTest {

    @InjectMocks
    private NullConstraintMessageValidator validator;

    private SalesTransactions getSalesTransactionsFromPath() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(new File("src/test/resources/samplejsons/Sample3.json"), SalesTransactions.class);
    }

    @Test
    @DisplayName("Should Able To Return List According To Missing Fields i in Map Object")
    public void validateMessageTest() throws IOException {
        SalesTransactions salesTransactions = null;
        Set<String> absentFields = validator.validateMessage(salesTransactions);
        assertTrue(absentFields.size() == 4);

        salesTransactions = new SalesTransactions();
        absentFields = validator.validateMessage(salesTransactions);
        assertTrue(absentFields.size() == 4);

        salesTransactions.setSaleTransactionMessage(new SaleTransactionMessage());
        absentFields = validator.validateMessage(salesTransactions);
        assertTrue(absentFields.size() == 4);

        salesTransactions = getSalesTransactionsFromPath();
        absentFields = validator.validateMessage(salesTransactions);
        assertTrue(absentFields.size() > 0);
    }
}
