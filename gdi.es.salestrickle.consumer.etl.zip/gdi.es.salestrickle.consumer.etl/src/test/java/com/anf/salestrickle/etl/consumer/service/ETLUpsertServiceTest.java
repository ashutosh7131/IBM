package com.anf.salestrickle.etl.consumer.service;

import com.anf.logservice.LoggingService;
import com.anf.salestrickle.etl.consumer.dao.ETLUpsertDao;
import com.anf.salestrickle.etl.consumer.model.kafka.SalesTransactions;
import com.anf.salestrickle.etl.consumer.util.mappers.ETLDBTableEntitiesMapper;
import com.anf.salestrickle.etl.consumer.util.validators.NullConstraintMessageValidator;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@ExtendWith(MockitoExtension.class)
public class ETLUpsertServiceTest {

    @Mock
    private ETLDBTableEntitiesMapper tableEntitiesMapper;

    @Mock
    private ETLUpsertDao etlUpsertDao;

    @Mock
    private LoggingService loggingService;

    @Mock
    private NullConstraintMessageValidator nullConstraintMessageValidator;

    @InjectMocks
    private ETLUpsertService etlUpsertService;


    private SalesTransactions getSalesTransactionsFromPath() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(new File("src/test/resources/samplejsons/Sample1.json"), SalesTransactions.class);
    }

    private SalesTransactions getSalesTransactionsFromPath2() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(new File("src/test/resources/samplejsons/Sample4.json"), SalesTransactions.class);
    }

    private String getJsonMessage() throws IOException {
        return new String(Files.readAllBytes(Paths.get("src/test/resources/samplejsons/Sample1.json")));
    }

    private SalesTransactions getInvalidSalesTransactionsFromPath() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(new File("src/test/resources/samplejsons/Sample3.json"), SalesTransactions.class);
    }


    private String getMalformedJsonMessage() throws IOException {
        return new String(Files.readAllBytes(Paths.get("src/test/resources/samplejsons/Sample3.json")));
    }

    @Test
    @DisplayName("Should Process Message")
    void shouldProcessMessage() throws Exception {

        SalesTransactions salesTransactions = getSalesTransactionsFromPath();
        assertDoesNotThrow(() -> etlUpsertService.saveDataToETLDB(salesTransactions, getJsonMessage()));

        SalesTransactions salesTransactions2 = getSalesTransactionsFromPath2();
        assertDoesNotThrow(() -> etlUpsertService.saveDataToETLDB(salesTransactions2, getJsonMessage()));

        SalesTransactions salesTransactions3 = getSalesTransactionsFromPath();
        List<String> downstreamSystemList = new ArrayList<String>();
        downstreamSystemList.add("LOYALTYPLUS");
        salesTransactions3.getSaleTransactionMessage().getSaleTransactionHDRType().setDownstreamSystemList(downstreamSystemList);
        assertDoesNotThrow(() -> etlUpsertService.saveDataToETLDB(salesTransactions3, getJsonMessage()));
    }
}
