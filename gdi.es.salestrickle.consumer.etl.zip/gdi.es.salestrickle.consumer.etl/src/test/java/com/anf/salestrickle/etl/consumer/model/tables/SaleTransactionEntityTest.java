package com.anf.salestrickle.etl.consumer.model.tables;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class SaleTransactionEntityTest {

    @Test
    @DisplayName("Should be able to set the values using the setters and retrieve them using the getters.")
    public void shouldBeAbleToSetTheValuesUsingTheSettersAndRetrieveThemUsingTheGetters() {

        var storeId = "1002";
        var workstationId = "102";
        var businessDate = "2023-01-04";
        var sequenceNumber = Double.valueOf(210);
        var storeType = "WEB";
        var employeeSaleId = "12";
        var cashierId = "13";
        var authorizerId = "10";
        var saleType = "SALE";
        var reasonCode = "RC";
        var startTime = new Date();
        var endTime = new Date();
        var taxExemptId = "TEI";
        var status = "ST";
        var filingCurrencyConversionFactor = Double.valueOf(10.2);
        ;
        var filingCurrencyCode = "FCC";
        var origCurrencyCode = "OCC";
        var subtotalAmount = 1002.0;
        var discountAmount = 210.0;
        var taxAmount = 102.0;
        var totalAmount = Double.valueOf(2100.0);
        var grandTotalAmount = Double.valueOf(1909.0);
        var originateEntryType = "OET";
        var originateStoreId = "1002";
        var originateWorkstationId = "102";
        var originateSequenceNumber = "210";
        var originateBusinessDate = "2023-02-10";
        var originateEnteredBy = "OEB";
        var demandStore = "DS";

        var saleTransactionEntity = new SaleTransactionEntity();

        saleTransactionEntity.setStoreId(storeId);
        saleTransactionEntity.setWorkstationId(workstationId);
        saleTransactionEntity.setBusinessDate(businessDate);
        saleTransactionEntity.setSequenceNumber(sequenceNumber);
        saleTransactionEntity.setStoreType(storeType);
        saleTransactionEntity.setEmployeeSaleId(employeeSaleId);
        saleTransactionEntity.setCashierId(cashierId);
        saleTransactionEntity.setAuthorizerId(authorizerId);
        saleTransactionEntity.setSaleType(saleType);
        saleTransactionEntity.setReasonCode(reasonCode);
        saleTransactionEntity.setStartTime(startTime);
        saleTransactionEntity.setEndTime(endTime);
        saleTransactionEntity.setTaxExemptId(taxExemptId);
        saleTransactionEntity.setStatus(status);
        saleTransactionEntity.setFilingCurrencyConversionFactor(filingCurrencyConversionFactor);
        saleTransactionEntity.setFilingCurrencyCode(filingCurrencyCode);
        saleTransactionEntity.setOrigCurrencyCode(origCurrencyCode);
        saleTransactionEntity.setSubtotalAmount(subtotalAmount);
        saleTransactionEntity.setDiscountAmount(discountAmount);
        saleTransactionEntity.setTaxAmount(taxAmount);
        saleTransactionEntity.setTotalAmount(totalAmount);
        saleTransactionEntity.setGrandTotalAmount(grandTotalAmount);
        saleTransactionEntity.setOriginateEntryType(originateEntryType);
        saleTransactionEntity.setOriginateStoreId(originateStoreId);
        saleTransactionEntity.setOriginateWorkstationId(originateWorkstationId);
        saleTransactionEntity.setOriginateSequenceNumber(originateSequenceNumber);
        saleTransactionEntity.setOriginateBusinessDate(originateBusinessDate);
        saleTransactionEntity.setOriginateEnteredBy(originateEnteredBy);
        saleTransactionEntity.setDemandStore(demandStore);

        assertAll(

                () -> assertEquals(storeId, saleTransactionEntity.getStoreId()),
                () -> assertEquals(workstationId, saleTransactionEntity.getWorkstationId()),
                () -> assertEquals(businessDate, saleTransactionEntity.getBusinessDate()),
                () -> assertEquals(sequenceNumber, saleTransactionEntity.getSequenceNumber()),
                () -> assertEquals(storeType, saleTransactionEntity.getStoreType()),
                () -> assertEquals(employeeSaleId, saleTransactionEntity.getEmployeeSaleId()),
                () -> assertEquals(cashierId, saleTransactionEntity.getCashierId()),
                () -> assertEquals(authorizerId, saleTransactionEntity.getAuthorizerId()),
                () -> assertEquals(saleType, saleTransactionEntity.getSaleType()),
                () -> assertEquals(reasonCode, saleTransactionEntity.getReasonCode()),
                () -> assertEquals(startTime, saleTransactionEntity.getStartTime()),
                () -> assertEquals(endTime, saleTransactionEntity.getEndTime()),
                () -> assertEquals(taxExemptId, saleTransactionEntity.getTaxExemptId()),
                () -> assertEquals(status, saleTransactionEntity.getStatus()),
                () -> assertEquals(filingCurrencyConversionFactor, saleTransactionEntity.getFilingCurrencyConversionFactor()),
                () -> assertEquals(filingCurrencyCode, saleTransactionEntity.getFilingCurrencyCode()),
                () -> assertEquals(origCurrencyCode, saleTransactionEntity.getOrigCurrencyCode()),
                () -> assertEquals(subtotalAmount, saleTransactionEntity.getSubtotalAmount()),
                () -> assertEquals(discountAmount, saleTransactionEntity.getDiscountAmount()),
                () -> assertEquals(taxAmount, saleTransactionEntity.getTaxAmount()),
                () -> assertEquals(totalAmount, saleTransactionEntity.getTotalAmount()),
                () -> assertEquals(grandTotalAmount, saleTransactionEntity.getGrandTotalAmount()),
                () -> assertEquals(originateEntryType, saleTransactionEntity.getOriginateEntryType()),
                () -> assertEquals(originateStoreId, saleTransactionEntity.getOriginateStoreId()),
                () -> assertEquals(originateWorkstationId, saleTransactionEntity.getOriginateWorkstationId()),
                () -> assertEquals(originateSequenceNumber, saleTransactionEntity.getOriginateSequenceNumber()),
                () -> assertEquals(originateBusinessDate, saleTransactionEntity.getOriginateBusinessDate()),
                () -> assertEquals(originateEnteredBy, saleTransactionEntity.getOriginateEnteredBy()),
                () -> assertEquals(demandStore, saleTransactionEntity.getDemandStore())


        );


    }
}
