package com.anf.salestrickle.etl.consumer.model.tables;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class DiscountLineItemEntityTest {

    @Test
    @DisplayName("Should be able to set the values using the setters and retrieve them using the getters.")
    public void shouldBeAbleToSetTheValuesUsingTheSettersAndRetrieveThemUsingTheGetters() {

        var storeId = "1002";
        var workstationId = "102";
        var businessDate = "2023-01-04";
        var sequenceNumber = Double.valueOf(210);
        var lineItemNumber = 1.0;
        var discountSequenceNumber = 2.0;
        var discounttype = "Coupon";
        var amount = 102.00;
        var promotionId = Double.valueOf(210);
        var aaaGid = 1002.00;
        var uniquePromotionCode = "ABCDE";

        var discountLineItemEntity = new DiscountLineItemEntity();

        discountLineItemEntity.setStoreId(storeId);
        discountLineItemEntity.setWorkstationId(workstationId);
        discountLineItemEntity.setBusinessDate(businessDate);
        discountLineItemEntity.setSequenceNumber(sequenceNumber);
        discountLineItemEntity.setLineItemNumber(lineItemNumber);
        discountLineItemEntity.setDiscountSequenceNumber(discountSequenceNumber);
        discountLineItemEntity.setDiscounttype(discounttype);
        discountLineItemEntity.setAmount(amount);
        discountLineItemEntity.setPromotionId(promotionId);
        discountLineItemEntity.setAaaGid(aaaGid);
        discountLineItemEntity.setUniquePromotionCode(uniquePromotionCode);

        assertAll(

                () -> assertEquals(storeId, discountLineItemEntity.getStoreId()),
                () -> assertEquals(workstationId, discountLineItemEntity.getWorkstationId()),
                () -> assertEquals(businessDate, discountLineItemEntity.getBusinessDate()),
                () -> assertEquals(sequenceNumber, discountLineItemEntity.getSequenceNumber()),
                () -> assertEquals(lineItemNumber, discountLineItemEntity.getLineItemNumber()),
                () -> assertEquals(discountSequenceNumber, discountLineItemEntity.getDiscountSequenceNumber()),
                () -> assertEquals(discounttype, discountLineItemEntity.getDiscounttype()),
                () -> assertEquals(amount, discountLineItemEntity.getAmount()),
                () -> assertEquals(promotionId, discountLineItemEntity.getPromotionId()),
                () -> assertEquals(aaaGid, discountLineItemEntity.getAaaGid()),
                () -> assertEquals(uniquePromotionCode, discountLineItemEntity.getUniquePromotionCode())

        );
    }
}
