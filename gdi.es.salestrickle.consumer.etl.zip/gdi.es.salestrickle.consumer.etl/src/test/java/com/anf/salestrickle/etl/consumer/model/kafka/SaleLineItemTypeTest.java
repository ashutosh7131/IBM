package com.anf.salestrickle.etl.consumer.model.kafka;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class SaleLineItemTypeTest {
    @Test
    @DisplayName("Should be able to set the values using the setters and retrieve them using the getters.")
    void shouldBeAbleToSetTheValuesUsingTheSettersAndRetrieveThemUsingTheGetters() {
        var lineItemNumber = 1234.00;
        var itemId = "234";
        var origItemId = "7645";
        var quantity = 1.00;
        var nonMerch = false;
        var ticketAmount = 534.00;
        var sellAmount = 345.00;
        var discountAmount = 10.00;
        var taxAmount = 10.00;
        var extendedAmount = 23.00;
        var voided = false;
        var giftReceiptPrinted = false;
        var maskedGiftCardId = "123";
        var origStoreId = "2435";
        var origBusinessDay = "test";
        var origWorkstationId = "1234";
        var origSequenceNumber = 23.00;
        var origLineItemNumber = 123.00;
        var origReceiptEntryMethod = "testcode";
        var origReceiptType = "test";
        var entryMethod = "test";
        var returnReasonCode = "code";
        var priceOverride = true;
        var priceOverrideReasonCode = "reasoncode";
        var taxOverride = true;
        var giftCardRequestType = "type";
        var encryptedGiftCardNumber = "1234";
        var shippingIntrastatCode = "testcode";
        var shippingMass = "mass";
        var shippingCountryOfOrigin = "US";
        var shippingFromCountry = "US";
        var discountLineItemList = new ArrayList<DiscountLineItemType>();
        var taxLineItemList = new ArrayList<TaxLineItemType>();
        var priceTypeCode = 20.00;
        var originateStockOutReasonCode = 10.00;
        var fulfillStoreID = "1324";
        var omniCode = "2534";

        var model = new SaleLineItemType();

        model.setLineItemNumber(lineItemNumber);
        model.setItemId(itemId);
        model.setOrigItemId(origItemId);
        model.setQuantity(quantity);
        model.setNonMerch(nonMerch);
        model.setTicketAmount(ticketAmount);
        model.setDiscountAmount(discountAmount);
        model.setSellAmount(sellAmount);
        model.setTaxAmount(taxAmount);
        model.setExtendedAmount(extendedAmount);
        model.setVoided(voided);
        model.setGiftReceiptPrinted(giftReceiptPrinted);
        model.setMaskedGiftCardId(maskedGiftCardId);
        model.setOrigStoreId(origStoreId);
        model.setOrigBusinessDay(origBusinessDay);
        model.setOrigWorkstationId(origWorkstationId);
        model.setOrigSequenceNumber(origSequenceNumber);
        model.setOrigLineItemNumber(origLineItemNumber);

        model.setOrigReceiptEntryMethod(origReceiptEntryMethod);
        model.setOrigReceiptType(origReceiptType);
        model.setEntryMethod(entryMethod);
        model.setReturnReasonCode(returnReasonCode);
        model.setPriceOverride(priceOverride);
        model.setPriceOverrideReasonCode(priceOverrideReasonCode);
        model.setTaxOverride(taxOverride);
        model.setGiftCardRequestType(giftCardRequestType);
        model.setEncryptedGiftCardNumber(encryptedGiftCardNumber);
        model.setShippingIntrastatCode(shippingIntrastatCode);
        model.setShippingMass(shippingMass);
        model.setShippingCountryOfOrigin(shippingCountryOfOrigin);
        model.setShippingFromCountry(shippingFromCountry);
        model.setDiscountLineItemList(discountLineItemList);
        model.setTaxLineItemList(taxLineItemList);
        model.setPriceTypeCode(priceTypeCode);
        model.setOriginateStockOutReasonCode(originateStockOutReasonCode);
        model.setFulfillStoreID(fulfillStoreID);
        model.setOmniCode(omniCode);

        assertAll(
                () -> assertEquals(lineItemNumber, model.getLineItemNumber()),
                () -> assertEquals(itemId, model.getItemId()),
                () -> assertEquals(origItemId, model.getOrigItemId()),
                () -> assertEquals(quantity, model.getQuantity()),
                () -> assertEquals(nonMerch, model.isNonMerch()),
                () -> assertEquals(ticketAmount, model.getTicketAmount()),
                () -> assertEquals(discountAmount, model.getDiscountAmount()),
                () -> assertEquals(sellAmount, model.getSellAmount()),
                () -> assertEquals(taxAmount, model.getTaxAmount()),
                () -> assertEquals(extendedAmount, model.getExtendedAmount()),
                () -> assertEquals(origReceiptEntryMethod, model.getOrigReceiptEntryMethod()),
                () -> assertEquals(origReceiptType, model.getOrigReceiptType()),
                () -> assertEquals(entryMethod, model.getEntryMethod()),
                () -> assertEquals(returnReasonCode, model.getReturnReasonCode()),
                () -> assertEquals(priceOverride, model.isPriceOverride()),
                () -> assertEquals(priceOverrideReasonCode, model.getPriceOverrideReasonCode()),
                () -> assertEquals(taxOverride, model.isTaxOverride()),
                () -> assertEquals(giftCardRequestType, model.getGiftCardRequestType()),
                () -> assertEquals(encryptedGiftCardNumber, model.getEncryptedGiftCardNumber()),
                () -> assertEquals(shippingIntrastatCode, model.getShippingIntrastatCode()),
                () -> assertEquals(shippingMass, model.getShippingMass()),
                () -> assertEquals(shippingCountryOfOrigin, model.getShippingCountryOfOrigin()),
                () -> assertEquals(shippingFromCountry, model.getShippingFromCountry()),
                () -> assertEquals(discountLineItemList, model.getDiscountLineItemList()),
                () -> assertEquals(taxLineItemList, model.getTaxLineItemList()),
                () -> assertEquals(priceTypeCode, model.getPriceTypeCode()),
                () -> assertEquals(originateStockOutReasonCode, model.getOriginateStockOutReasonCode()),
                () -> assertEquals(fulfillStoreID, model.getFulfillStoreID()),
                () -> assertEquals(omniCode, model.getOmniCode())

        );


    }
}
