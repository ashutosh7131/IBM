package com.anf.salestrickle.etl.consumer.model.kafka;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class DiscountLineItemTypeTest {

    @Test
    @DisplayName("Should be able to set the values using the setters and retrieve them using the getters.")
    void shouldBeAbleToSetTheValuesUsingTheSettersAndRetrieveThemUsingTheGetters() {
        var discountSequenceNumber = 1234.00;
        var discounttype = DiscountLineItemType.Discounttype.COUPON;
        var amount = 10.00;
        var promotionId = "324";
        var uniquePromotionCode = "123";
        var aaaGid = 1.00;

        var model = new DiscountLineItemType();
        model.setAaaGid(aaaGid);
        model.setAmount(amount);
        model.setDiscountSequenceNumber(discountSequenceNumber);
        model.setDiscounttype(discounttype);
        model.setPromotionId(promotionId);
        model.setUniquePromotionCode(uniquePromotionCode);

        assertAll(
                () -> assertEquals(aaaGid, model.getAaaGid()),
                () -> assertEquals(amount, model.getAmount()),
                () -> assertEquals(discountSequenceNumber, model.getDiscountSequenceNumber()),
                () -> assertEquals(discounttype, model.getDiscounttype()),
                () -> assertEquals(promotionId, model.getPromotionId()),
                () -> assertEquals(uniquePromotionCode, model.getUniquePromotionCode())
        );

    }

    @Test
    @DisplayName("Enum Should return proper value")
    void enumShouldReturnProperVAlue() {
        String value = "ITEM";
        assertEquals(DiscountLineItemType.Discounttype.ITEM.value(), value);
        assertEquals(DiscountLineItemType.Discounttype.fromValue(value), DiscountLineItemType.Discounttype.ITEM);
    }
}
