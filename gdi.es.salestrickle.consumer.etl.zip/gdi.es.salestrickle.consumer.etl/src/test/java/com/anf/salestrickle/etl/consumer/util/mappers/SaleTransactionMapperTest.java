package com.anf.salestrickle.etl.consumer.util.mappers;

import com.anf.salestrickle.etl.consumer.model.kafka.SalesTransactions;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;


@ExtendWith(MockitoExtension.class)
public class SaleTransactionMapperTest {

    @Mock
    private CustomerInfoMapper customerInfoMapper;

    @InjectMocks
    private SaleTransactionMapper mapper;

    private SalesTransactions getSalesTransactionsFromPath() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(new File("src/test/resources/samplejsons/Sample1.json"), SalesTransactions.class);
    }

    @Test
    @DisplayName("Should Able To Map Entities in Map Object")
    public void mapEntities() throws IOException {
        Map<String, Object> map = new HashMap<String, Object>();
        SalesTransactions salesTransactions = getSalesTransactionsFromPath();
        mapper.mapToSaleTransactionEntity(salesTransactions.getSaleTransactionMessage(), map);
        assertDoesNotThrow(() -> mapper.mapToSaleTransactionEntity(salesTransactions.getSaleTransactionMessage(), map));
    }
}
