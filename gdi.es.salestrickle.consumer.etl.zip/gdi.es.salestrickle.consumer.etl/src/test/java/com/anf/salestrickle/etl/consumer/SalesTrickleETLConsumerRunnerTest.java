package com.anf.salestrickle.etl.consumer;


import com.anf.kafkaservicejsonschema.models.Consumer;
import com.anf.logservice.LoggingService;
import com.anf.salestrickle.etl.consumer.model.kafka.SalesTransactions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class SalesTrickleETLConsumerRunnerTest {

    @Mock
    LoggingService logservice;
    @Mock
    private Consumer<SalesTransactions> consumer;
    @InjectMocks
    private SalesTrickleETLConsumerRunner runner;

    @Test
    @DisplayName("Should start consuming kafka messages when run method is called")
    void shouldStartConsumingMessagesWhenRunMethodIsCalled() throws Exception {
        runner.run();
        verify(consumer, times(1)).processRecords();
    }
}
