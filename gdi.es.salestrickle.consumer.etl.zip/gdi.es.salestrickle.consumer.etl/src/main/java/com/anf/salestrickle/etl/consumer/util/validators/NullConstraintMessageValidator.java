package com.anf.salestrickle.etl.consumer.util.validators;

import com.anf.salestrickle.etl.consumer.model.kafka.SaleLineItemType;
import com.anf.salestrickle.etl.consumer.model.kafka.SaleTransactionHDRType;
import com.anf.salestrickle.etl.consumer.model.kafka.SalesTransactions;
import com.anf.salestrickle.etl.consumer.model.kafka.TaxLineItemType;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.anf.salestrickle.etl.consumer.data.Constants.*;
import static org.apache.commons.lang3.StringUtils.isAllBlank;

@Component
public class NullConstraintMessageValidator {

    public Set<String> validateMessage(@NotNull SalesTransactions salesTransactions) {
        Set<String> absentMandatoryFields = new HashSet<String>();

        if (null == salesTransactions || null == salesTransactions.getSaleTransactionMessage()
                || null == salesTransactions.getSaleTransactionMessage().getSaleTransactionHDRType()) {
            absentMandatoryFields.add(BUSINESS_DATE);
            absentMandatoryFields.add(SEQUENCE_NUMBER);
            absentMandatoryFields.add(STORE_ID);
            absentMandatoryFields.add(WORKSTATION_ID);
        } else {
            SaleTransactionHDRType saleTransactionHDRType = salesTransactions.getSaleTransactionMessage().getSaleTransactionHDRType();

            if (isAllBlank(saleTransactionHDRType.getBusinessDate())) {
                absentMandatoryFields.add(BUSINESS_DATE);
            }

            if (isAllBlank(saleTransactionHDRType.getSequenceNumber())) {
                absentMandatoryFields.add(SEQUENCE_NUMBER);
            }

            if (isAllBlank(saleTransactionHDRType.getStoreId())) {
                absentMandatoryFields.add(STORE_ID);
            }

            if (isAllBlank(saleTransactionHDRType.getWorkstationId())) {
                absentMandatoryFields.add(WORKSTATION_ID);
            }

            if (isAllBlank(saleTransactionHDRType.getStoreType())) {
                absentMandatoryFields.add(STORE_TYPE);
            }

            List<SaleLineItemType> saleLineItemTypeList = salesTransactions.getSaleTransactionMessage().getSaleTransactionItems();
            if (null != saleLineItemTypeList) {
                for (SaleLineItemType saleLineItemType :
                        saleLineItemTypeList) {
                    List<TaxLineItemType> taxLineItemTypeList = saleLineItemType.getTaxLineItemList();
                    if (null != taxLineItemTypeList) {
                        for (TaxLineItemType taxLineItemType :
                                taxLineItemTypeList) {
                            if (isAllBlank(taxLineItemType.getAuthority())) {
                                absentMandatoryFields.add(TAX_AUTHORITY);
                            }
                        }
                    }
                }
            }
        }

        return absentMandatoryFields;
    }
}
