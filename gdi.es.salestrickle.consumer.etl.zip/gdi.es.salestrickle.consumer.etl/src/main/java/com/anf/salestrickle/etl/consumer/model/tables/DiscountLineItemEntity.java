package com.anf.salestrickle.etl.consumer.model.tables;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DiscountLineItemEntity {

    private String storeId;
    private String workstationId;
    private String businessDate;
    private Double sequenceNumber;
    private double lineItemNumber;
    private double discountSequenceNumber;
    private String discounttype;
    private double amount;
    private Double promotionId;
    private double aaaGid;
    private String uniquePromotionCode;
}
