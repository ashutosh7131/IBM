package com.anf.salestrickle.etl.consumer.model.tables;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TenderEntity {

    private String storeId;
    private String workstationId;
    private String businessDate;
    private String sequenceNumber;
    private double tenderNumber;
    private double tenderAmount;
    private String accountName;
    private String tenderType;
    private String tenderTypeId;
    private String cardAuthMethod;
    private String cardAuthReturnCode;
    private String cardEntryMode;
    private String encryptedExpDate;
    private String encryptedCardNumber;
    private String maskedCardNumber;
    private String encryptedCheckRoutingNumber;
    private String encryptedCheckAccountNumber;
    private String hashedCardNumber;
    private Double lineItemNumber;
    private String storeCurrencyCode;
    private Double tenderExchangeRate;
    private String foreignTenderCurrencyCode;
    private Double foreignTenderAmount;
    private String encryptionType;
}
