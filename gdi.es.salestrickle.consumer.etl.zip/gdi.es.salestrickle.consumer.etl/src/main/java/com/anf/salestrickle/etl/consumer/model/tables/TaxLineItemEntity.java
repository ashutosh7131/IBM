package com.anf.salestrickle.etl.consumer.model.tables;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TaxLineItemEntity {

    private String storeId;
    private String workstationId;
    private String businessDate;
    private String sequenceNumber;
    private double lineItemNumber;
    private String taxLinetype;
    private String authority;
    private String amount;
    private String rate;
    private String name;
}
