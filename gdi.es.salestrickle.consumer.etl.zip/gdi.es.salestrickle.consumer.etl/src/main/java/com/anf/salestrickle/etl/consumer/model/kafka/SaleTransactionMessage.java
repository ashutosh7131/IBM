package com.anf.salestrickle.etl.consumer.model.kafka;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

import javax.annotation.Generated;
import javax.validation.constraints.NotNull;
import java.util.List;


/**
 * Sale Transaction Type
 */
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "saleTransactionHDRType",
        "saleTransactionItems"
})
@Generated("jsonschema2pojo")
public class SaleTransactionMessage {

    /**
     * Sale Transaction HDR Type
     * (Required)
     */
    @JsonProperty("saleTransactionHDRType")
    @JsonPropertyDescription("Sale Transaction HDR Type")
    @NotNull
    public SaleTransactionHDRType saleTransactionHDRType;
    /**
     * Sale Transaction Items Type
     */
    @JsonProperty("saleTransactionItems")
    @JsonPropertyDescription("Sale Transaction Items Type")
    public List<SaleLineItemType> saleTransactionItems = null;

}
