package com.anf.salestrickle.etl.consumer.service;

import com.anf.kafkaservicejsonschema.models.Consumer;
import com.anf.kafkaservicejsonschema.models.Producer;
import com.anf.logservice.LoggingService;
import com.anf.logservice.models.LogRequest;
import com.anf.salestrickle.etl.consumer.config.AppKafkaConfig;
import com.anf.salestrickle.etl.consumer.model.kafka.SalesTransactions;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.validation.constraints.NotNull;
import java.util.UUID;

import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Service
public class ETLConsumerService {

    private final Consumer<SalesTransactions> consumer;

    private final AppKafkaConfig kafkaProperties;

    private LoggingService loggingService;

    private Producer<SalesTransactions> producer;

    @Autowired
    private ETLUpsertService etlUpsertService;

    @Autowired
    public ETLConsumerService(Consumer<SalesTransactions> consumer, LoggingService loggingService, AppKafkaConfig kafkaProperties, @Qualifier("DltProducer") Producer<SalesTransactions> producer) {
        this.consumer = consumer;
        this.kafkaProperties = kafkaProperties;
        this.loggingService = LoggingService.getNew(ETLConsumerService.class);
        this.producer = producer;
    }

    public void processEvent(@NotNull SalesTransactions salesTransactions) {

        loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "PROCESSING MESSAGE for ETL DB :: " + salesTransactions.toString()).defaultLogger());
        String jsonMessage = EMPTY;
        try {
            jsonMessage = toJsonString(salesTransactions);
            etlUpsertService.saveDataToETLDB(salesTransactions, jsonMessage);
        } catch (Exception e) {
            loggingService.log(LogRequest.error(UUID.randomUUID(), e).defaultLogger());
            if (isNotBlank(jsonMessage)) {
                postMessageToDeadLetterTopic(salesTransactions, jsonMessage);
            }
        } finally {
            consumer.messageProcessed();
        }
    }

    private String toJsonString(SalesTransactions salesTransactions) {
        String jsonString = EMPTY;
        try {
            jsonString = new ObjectMapper().writeValueAsString(salesTransactions);
        } catch (JsonProcessingException exception) {
            var errorMessage = String.format(" ERROR While Generating JSON String");
            if (isNotBlank(exception.getMessage())) {
                errorMessage = String.format(" - ", errorMessage, exception.getMessage());
            }
            loggingService.log(LogRequest.error(salesTransactions.getCorrelationId(), exception, errorMessage)
                    .defaultLogger()
                    .addObjects("ETL_DB_EVENT - Error While Generating JSON String", salesTransactions));
        } finally {
            return jsonString;
        }
    }

    private void postMessageToDeadLetterTopic(SalesTransactions payLoad, String jsonMessage) {
        try {
            loggingService.log(LogRequest.debug(payLoad.getCorrelationId(), "PROCESSING to produce MESSAGE :: " + jsonMessage).defaultLogger());
            producer.sendMessage(payLoad, payLoad.getCorrelationId().toString());
            loggingService.log(LogRequest.warn(payLoad.getCorrelationId(), String.format(" - Kafka message sent to DLT topic For ETL DB"))
                    .addObjects(payLoad)
                    .defaultLogger()
            );
        } catch (Exception e) {
            var errorMessage = String.format(" ERROR SENDING TO DLT TOPIC for ETL DB");
            if (isNotBlank(e.getMessage())) {
                errorMessage = String.format(errorMessage.concat(" %s"), e.getMessage());
            }
            loggingService.log(LogRequest.error(payLoad.getCorrelationId(), e, errorMessage)
                    .defaultLogger()
                    .addObjects("ETL_DB_EVENT", payLoad)
            );
        }
    }
}
