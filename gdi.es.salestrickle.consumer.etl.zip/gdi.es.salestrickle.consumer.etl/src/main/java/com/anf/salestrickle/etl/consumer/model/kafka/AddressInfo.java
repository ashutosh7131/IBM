package com.anf.salestrickle.etl.consumer.model.kafka;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

import javax.annotation.Generated;


/**
 * Address information.
 */
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "address1",
        "address2",
        "city",
        "state",
        "zipCode",
        "zipCodeExt",
        "country"
})
@Generated("jsonschema2pojo")
public class AddressInfo {

    /**
     * Address Line 1
     */
    @JsonProperty("address1")
    @JsonPropertyDescription("Address Line 1")
    public String address1;
    /**
     * Address Line 2
     */
    @JsonProperty("address2")
    @JsonPropertyDescription("Address Line 2")
    public String address2;
    /**
     * City
     */
    @JsonProperty("city")
    @JsonPropertyDescription("City")
    public String city;
    /**
     * State
     */
    @JsonProperty("state")
    @JsonPropertyDescription("State")
    public String state;
    /**
     * Zip Code
     */
    @JsonProperty("zipCode")
    @JsonPropertyDescription("Zip Code")
    public String zipCode;
    /**
     * Zip Code Ext
     */
    @JsonProperty("zipCodeExt")
    @JsonPropertyDescription("Zip Code Ext")
    public String zipCodeExt;
    /**
     * Country
     */
    @JsonProperty("country")
    @JsonPropertyDescription("Country")
    public String country;

}
