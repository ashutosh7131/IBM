package com.anf.salestrickle.etl.consumer.dao;

import com.anf.logservice.LoggingService;
import com.anf.logservice.models.LogRequest;
import com.anf.salestrickle.etl.consumer.model.kafka.SalesTransactions;
import com.anf.salestrickle.etl.consumer.model.tables.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.anf.salestrickle.etl.consumer.data.Constants.*;
import static com.anf.salestrickle.etl.consumer.data.SqlContsants.*;
import static org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils.createBatch;

@SuppressWarnings("ALL")
@Repository
public class ETLUpsertDao {

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Autowired
    private LoggingService loggingService;

    @Transactional
    public void saveAllBatch(SalesTransactions salesTransactions, Map<String, Object> map) throws Exception {

        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "ETL DB INSERTION PROCESS BEGIN :: ").defaultLogger());

        try {
            if (null != map && !map.isEmpty()) {
                String operationType = (String) map.get(OPERATION_TYPE);

                if (INSERT.equalsIgnoreCase(operationType)) {

                    if (map.containsKey(SALE_TRANSACTION_ENTITY)) {
                        SaleTransactionEntity saleTransactionEntity = (SaleTransactionEntity) map.get(SALE_TRANSACTION_ENTITY);
                        saveToSaleTransactionTable(saleTransactionEntity, salesTransactions);
                    }

                    if (map.containsKey(CUSTOMER_INFO_ENTITY)) {
                        CustomerInfoEntity customerInfoEntity = (CustomerInfoEntity) map.get(CUSTOMER_INFO_ENTITY);
                        saveToCustomerInfoTable(customerInfoEntity, salesTransactions);
                    }

                    if (map.containsKey(TENDER_ENTITY_LIST)) {
                        List<TenderEntity> tenderEntityList = (List<TenderEntity>) map.get(TENDER_ENTITY_LIST);
                        saveToTenderTable(TENDER_INSERT_SQL, tenderEntityList, salesTransactions);
                    }

                    if (map.containsKey(SALE_LINE_ITEM_ENTITY_LIST)) {
                        List<SaleLineItemEntity> saleLineItemEntityList = (List<SaleLineItemEntity>) map.get(SALE_LINE_ITEM_ENTITY_LIST);
                        saveToSaleItemTable(saleLineItemEntityList, salesTransactions);
                    }

                    if (map.containsKey(TAX_LINE_ITEM_ENTITY_LIST)) {
                        List<TaxLineItemEntity> taxLineItemEntityList = (List<TaxLineItemEntity>) map.get(TAX_LINE_ITEM_ENTITY_LIST);
                        saveToTaxItemTable(taxLineItemEntityList, salesTransactions);
                    }

                    if (map.containsKey(DISCOUNT_LINE_ITEM_ENTITY_LIST)) {
                        List<DiscountLineItemEntity> discountLineItemEntityList = (List<DiscountLineItemEntity>) map.get(DISCOUNT_LINE_ITEM_ENTITY_LIST);
                        saveToDiscountItemTable(discountLineItemEntityList, salesTransactions);
                    }

                } else if (UPDATE.equalsIgnoreCase(operationType)) {

                    if (map.containsKey(TENDER_ENTITY_LIST)) {
                        List<TenderEntity> tenderEntityList = (List<TenderEntity>) map.get(TENDER_ENTITY_LIST);
                        saveToTenderTable(TENDER_UPD_INSERT_SQL, tenderEntityList, salesTransactions);
                    }

                }
            }
        } catch (DataIntegrityViolationException sqlException) {
            loggingService.log(LogRequest.error(salesTransactions.getCorrelationId(), sqlException, (sqlException.getMessage() + "\n JSON Message : \n " + (String) map.get(JSON_MESSAGE_STRING)))
                    .defaultLogger());
        } finally {
            this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "ETL DB INSERTION PROCESS END :: ").defaultLogger());
        }
    }


    private void saveToSaleTransactionTable(SaleTransactionEntity saleTransactionEntity, SalesTransactions salesTransactions) throws DataIntegrityViolationException, Exception {
        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "INSIDE saveToSaleTransactionTable()  :: " + saleTransactionEntity.toString()).defaultLogger());
        SqlParameterSource source = new BeanPropertySqlParameterSource(saleTransactionEntity); //createBatch(saleTransactionEntity);
        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "INSIDE saveToSaleTransactionTable()  create :: " + source).defaultLogger());
        int intArr = namedParameterJdbcTemplate.update(SALE_TRANSACTION_INSERT_SQL, source);
        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "INSIDE saveToSaleTransactionTable()  update :: " + intArr).defaultLogger());
    }

    private void saveToCustomerInfoTable(CustomerInfoEntity customerInfoEntity, SalesTransactions salesTransactions) throws DataIntegrityViolationException, Exception {
        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "INSIDE saveToCustomerInfoTable()  :: " + customerInfoEntity).defaultLogger());
        SqlParameterSource source = new BeanPropertySqlParameterSource(customerInfoEntity);
        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "INSIDE saveToCustomerInfoTable()  create :: " + source).defaultLogger());
        int intArr = namedParameterJdbcTemplate.update(CUSTOMER_INFO_INSERT_SQL, source);
        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "INSIDE saveToCustomerInfoTable()  update :: " + intArr).defaultLogger());
    }

    private void saveToTenderTable(String sql, List<TenderEntity> tenderEntityList, SalesTransactions salesTransactions) throws DataIntegrityViolationException, Exception {
        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "INSIDE saveToTenderTable()  :: " + tenderEntityList).defaultLogger());
        SqlParameterSource[] source = createBatch(tenderEntityList);
        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "INSIDE saveToTenderTable() createBatch :: " + source).defaultLogger());
        int[] intArr = namedParameterJdbcTemplate.batchUpdate(sql, source);
        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "INSIDE saveToTenderTable()  batchUpdate :: " + intArr).defaultLogger());
    }

    private void saveToSaleItemTable(List<SaleLineItemEntity> saleLineItemEntityList, SalesTransactions salesTransactions) throws DataIntegrityViolationException, Exception {
        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "INSIDE saveToSaleItemTable()  :: " + saleLineItemEntityList).defaultLogger());
        SqlParameterSource[] source = createBatch(saleLineItemEntityList);
        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "INSIDE saveToSaleItemTable() createBatch :: " + source).defaultLogger());
        int[] intArr = namedParameterJdbcTemplate.batchUpdate(SALE_LINE_ITEM_INSERT_SQL, source);
        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "INSIDE saveToSaleItemTable()  batchUpdate :: " + intArr).defaultLogger());
    }

    private void saveToTaxItemTable(List<TaxLineItemEntity> taxLineItemEntityList, SalesTransactions salesTransactions) throws DataIntegrityViolationException, Exception {
        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "INSIDE saveToTaxItemTable()  :: " + taxLineItemEntityList).defaultLogger());
        SqlParameterSource[] source = createBatch(taxLineItemEntityList);
        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "INSIDE saveToTaxItemTable() createBatch :: " + source).defaultLogger());
        int[] intArr = namedParameterJdbcTemplate.batchUpdate(TAX_LINE_ITEM_INSERT_SQL, source);
        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "INSIDE saveToTaxItemTable()  batchUpdate :: " + intArr).defaultLogger());
    }

    private void saveToDiscountItemTable(List<DiscountLineItemEntity> discountLineItemEntityList, SalesTransactions salesTransactions) throws DataIntegrityViolationException, Exception {
        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "INSIDE saveToDiscountItemTable()  :: " + discountLineItemEntityList).defaultLogger());
        SqlParameterSource[] source = createBatch(discountLineItemEntityList);
        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "INSIDE saveToDiscountItemTable() createBatch :: " + source).defaultLogger());
        int[] intArr = namedParameterJdbcTemplate.batchUpdate(DISCOUNT_LINE_ITEM_INSERT_SQL, source);
        this.loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "INSIDE saveToDiscountItemTable()  batchUpdate :: " + intArr).defaultLogger());
    }
}
