package com.anf.salestrickle.etl.consumer.model.kafka;

import com.fasterxml.jackson.annotation.*;
import lombok.Getter;
import lombok.Setter;

import javax.annotation.Generated;
import javax.validation.constraints.NotNull;
import java.util.HashMap;
import java.util.Map;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "discountSequenceNumber",
        "discounttype",
        "amount",
        "promotionId",
        "uniquePromotionCode",
        "aaaGid"
})
@Generated("jsonschema2pojo")
public class DiscountLineItemType {

    /**
     * Discount Sequence Number
     */
    @JsonProperty("discountSequenceNumber")
    @JsonPropertyDescription("Discount Sequence Number")
    @NotNull
    public double discountSequenceNumber;
    /**
     * Discount Type Type
     */
    @JsonProperty("discounttype")
    @JsonPropertyDescription("Discount Type Type")
    public Discounttype discounttype;
    /**
     * Amount
     */
    @JsonProperty("amount")
    @JsonPropertyDescription("Amount")
    public double amount;
    /**
     * Promotion Id
     */
    @JsonProperty("promotionId")
    @JsonPropertyDescription("Promotion Id")
    public String promotionId;
    /**
     * Unique Promotion Code
     */
    @JsonProperty("uniquePromotionCode")
    @JsonPropertyDescription("Unique Promotion Code")
    public String uniquePromotionCode;
    /**
     * aaaGid
     */
    @JsonProperty("aaaGid")
    @JsonPropertyDescription("aaaGid")
    public double aaaGid;


    /**
     * Discount Type Type
     */
    @Generated("jsonschema2pojo")
    public enum Discounttype {

        ITEM("ITEM"),
        COUPON("COUPON"),
        EMPLOYEE("EMPLOYEE"),
        UNKNOWN("UNKNOWN");
        private final static Map<String, Discounttype> CONSTANTS = new HashMap<String, Discounttype>();

        static {
            for (Discounttype c : values()) {
                CONSTANTS.put(c.value, c);
            }
        }

        private final String value;

        Discounttype(String value) {
            this.value = value;
        }

        @JsonCreator
        public static Discounttype fromValue(String value) {
            Discounttype constant = CONSTANTS.get(value);
            if (constant == null) {
                throw new IllegalArgumentException(value);
            } else {
                return constant;
            }
        }

        @Override
        public String toString() {
            return this.value;
        }

        @JsonValue
        public String value() {
            return this.value;
        }

    }

}
