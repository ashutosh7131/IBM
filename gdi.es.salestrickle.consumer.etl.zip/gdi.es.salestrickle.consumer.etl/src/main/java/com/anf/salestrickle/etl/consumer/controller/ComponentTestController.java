package com.anf.salestrickle.etl.consumer.controller;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.anf.kafkaservicejsonschema.models.Producer;
import com.anf.logservice.LoggingService;
import com.anf.logservice.models.LogRequest;
import com.anf.salestrickle.etl.consumer.config.AppKafkaConfig;
import com.anf.salestrickle.etl.consumer.model.kafka.SalesTransactions;
import com.anf.salestrickle.etl.consumer.service.ETLConsumerService;

@RestController
public class ComponentTestController {
	
	private final AppKafkaConfig kafkaProperties;

    private LoggingService loggingService;

    private Producer<SalesTransactions> producer;
    
    
    @Autowired
    public ComponentTestController(AppKafkaConfig kafkaProperties, LoggingService loggingService, @Qualifier("Producer") Producer<SalesTransactions> producer) {
    	this.kafkaProperties = kafkaProperties;
        this.loggingService = LoggingService.getNew(ETLConsumerService.class);
        this.producer = producer;
    }
	
	@PostMapping("/produce")
	public void produceForComponentTest(@RequestBody SalesTransactions salesTransactions) {
		try {
        	UUID uuid = salesTransactions.getCorrelationId();
        	
        	if (null == uuid) {
				uuid = UUID.randomUUID();
				salesTransactions.setCorrelationId(uuid);
			}
        	
            loggingService.log(LogRequest.debug(salesTransactions.getCorrelationId(), "PROCESSING to produce MESSAGE :: ").defaultLogger());
            producer.sendMessage(salesTransactions, salesTransactions.getCorrelationId().toString());
            loggingService.log(LogRequest.warn(salesTransactions.getCorrelationId(), String.format(" - Kafka message sent to topic To Run Component Test For ETL DB"))
                    .addObjects(salesTransactions)
                    .defaultLogger()
            );
        } catch (Exception e) {
            var errorMessage = String.format("ERROR SENDING TO TOPIC To Run Component Test for ETL DB");
            if (isNotBlank(e.getMessage())) {
                errorMessage = String.format(errorMessage.concat(" %s"), e.getMessage());
            }
            loggingService.log(LogRequest.error(salesTransactions.getCorrelationId(), e, errorMessage)
                    .defaultLogger()
                    .addObjects("ETL_DB_EVENT", salesTransactions)
            );
        }
	}
	
	@DeleteMapping("/delete")
	public void deleteDataInDB(@RequestBody SalesTransactions salesTransactions) {
		
	}

	private void postMessageToTopic(SalesTransactions payLoad) {
        
    }
}
