package com.anf.salestrickle.etl.consumer.util.mappers;

import com.anf.salestrickle.etl.consumer.model.kafka.SaleTransactionHDRType;
import com.anf.salestrickle.etl.consumer.model.kafka.SaleTransactionMessage;
import com.anf.salestrickle.etl.consumer.model.tables.SaleTransactionEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Map;

import static com.anf.salestrickle.etl.consumer.data.Constants.SALE_TRANSACTION_ENTITY;

@Component
public class SaleTransactionMapper {

    @Autowired
    private CustomerInfoMapper customerInfoMapper;

    public void mapToSaleTransactionEntity(SaleTransactionMessage saleTransactionMessage, Map<String, Object> map) {
        SaleTransactionHDRType saleTransactionHDRType = saleTransactionMessage.getSaleTransactionHDRType();
        if (null != saleTransactionHDRType) {
            SaleTransactionEntity saleTransactionEntity = new SaleTransactionEntity();
            saleTransactionEntity.setStoreId(saleTransactionHDRType.getStoreId());
            saleTransactionEntity.setWorkstationId(saleTransactionHDRType.getWorkstationId());
            saleTransactionEntity.setBusinessDate(saleTransactionHDRType.getBusinessDate());
            saleTransactionEntity.setSequenceNumber(Double.parseDouble(saleTransactionHDRType.getSequenceNumber()));
            saleTransactionEntity.setStoreType(saleTransactionHDRType.getStoreType());
            saleTransactionEntity.setEmployeeSaleId(saleTransactionHDRType.getEmployeeSaleId());
            saleTransactionEntity.setCashierId(saleTransactionHDRType.getCashierId());
            saleTransactionEntity.setAuthorizerId(saleTransactionHDRType.getAuthorizerId());
            saleTransactionEntity.setSaleType(saleTransactionHDRType.getSaleType());
            saleTransactionEntity.setReasonCode(saleTransactionHDRType.getReasonCode());
            saleTransactionEntity.setStartTime(mapStartDate(saleTransactionHDRType));
            saleTransactionEntity.setEndTime(mapEndDate(saleTransactionHDRType));
            saleTransactionEntity.setTaxExemptId(saleTransactionHDRType.getTaxExemptId());
            saleTransactionEntity.setStatus(saleTransactionHDRType.getStatus());
            saleTransactionEntity.setFilingCurrencyConversionFactor(saleTransactionHDRType.getFilingCurrencyConversionFactor());
            saleTransactionEntity.setFilingCurrencyCode(saleTransactionHDRType.getFilingCurrencyCode());
            saleTransactionEntity.setOrigCurrencyCode(saleTransactionHDRType.getOrigCurrencyCode());
            saleTransactionEntity.setSubtotalAmount(saleTransactionHDRType.getSubtotalAmount());
            saleTransactionEntity.setDiscountAmount(saleTransactionHDRType.getDiscountAmount());
            saleTransactionEntity.setTaxAmount(saleTransactionHDRType.getTaxAmount());
            saleTransactionEntity.setTotalAmount(saleTransactionHDRType.getTotalAmount());
            saleTransactionEntity.setOriginateEntryType(saleTransactionHDRType.getOriginateEntryType());
            saleTransactionEntity.setOriginateStoreId(saleTransactionHDRType.getOriginateStoreId());
            saleTransactionEntity.setOriginateWorkstationId(saleTransactionHDRType.getOriginateWorkstationId());
            saleTransactionEntity.setOriginateSequenceNumber(saleTransactionHDRType.getOriginateSequenceNumber());
            saleTransactionEntity.setOriginateBusinessDate(saleTransactionHDRType.getOriginateBusinessDate());
            saleTransactionEntity.setOriginateEnteredBy(saleTransactionHDRType.getOriginateEnteredBy());
            saleTransactionEntity.setDemandStore(saleTransactionHDRType.getDemandStore());
            customerInfoMapper.mapToCustomerInfoEntity(saleTransactionMessage, map);
            map.put(SALE_TRANSACTION_ENTITY, saleTransactionEntity);
        }
    }

    private Date mapStartDate(SaleTransactionHDRType saleTransactionHDRType) {

        Date date = saleTransactionHDRType.getStartTime();
        Date tranStartDate = saleTransactionHDRType.getTransactionStartTime();
        if (null != tranStartDate) {
            date = tranStartDate;
        }
        return date;
    }

    private Date mapEndDate(SaleTransactionHDRType saleTransactionHDRType) {

        Date date = saleTransactionHDRType.getEndTime();
        Date tranEndDate = saleTransactionHDRType.getTransactionEndTime();
        if (null != tranEndDate) {
            date = tranEndDate;
        }
        return date;
    }
}
