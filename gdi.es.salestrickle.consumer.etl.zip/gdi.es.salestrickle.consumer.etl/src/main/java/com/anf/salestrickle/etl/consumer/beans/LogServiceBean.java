package com.anf.salestrickle.etl.consumer.beans;

import com.anf.logservice.LoggingService;
import com.anf.salestrickle.etl.consumer.Application;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class LogServiceBean {
    @Bean(name = "kafka-loggingService-bean")
    public LoggingService getLoggingService() {
        return LoggingService.getNew(Application.class);
    }
}
