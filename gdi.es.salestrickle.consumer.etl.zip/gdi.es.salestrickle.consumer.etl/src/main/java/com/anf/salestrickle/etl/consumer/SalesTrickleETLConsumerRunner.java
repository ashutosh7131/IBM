package com.anf.salestrickle.etl.consumer;

import com.anf.kafkaservicejsonschema.models.Consumer;
import com.anf.logservice.LoggingService;
import com.anf.logservice.models.LogRequest;
import com.anf.salestrickle.etl.consumer.config.AppKafkaConfig;
import com.anf.salestrickle.etl.consumer.model.kafka.SalesTransactions;
import com.anf.salestrickle.etl.consumer.service.ETLConsumerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.UUID;

@Component
public class SalesTrickleETLConsumerRunner implements CommandLineRunner {

    private final Consumer<SalesTransactions> consumer;
    private final LoggingService loggingService;
    private final AppKafkaConfig kafkaProperties;
    private final ETLConsumerService messageProcessor;

    @Autowired
    public SalesTrickleETLConsumerRunner(Consumer<SalesTransactions> consumer, LoggingService loggingService, AppKafkaConfig kafkaProperties, ETLConsumerService messageProcessor) {

        this.consumer = consumer;
        this.loggingService = loggingService;
        this.kafkaProperties = kafkaProperties;
        this.messageProcessor = messageProcessor;
    }

    @Override
    public void run(String... args) throws Exception {

        System.out.println(":::ETL-DB CONSUMER STARTING");
        this.loggingService.log(LogRequest
                .info(UUID.randomUUID(), ":::ETL-DB CONSUMER STARTING").defaultLogger());

        try {
            var parameterTypes = new Class[1];
            parameterTypes[0] = SalesTransactions.class;
            Method functionToPass = ETLConsumerService.class.getMethod("processEvent", parameterTypes);
            consumer.setCallback(messageProcessor, functionToPass);
            consumer.processRecords();
        } catch (java.lang.Exception ex) {
            LogRequest kafkaPayloadLog = LogRequest.error(UUID.randomUUID(), ex).defaultLogger();
            loggingService.log(kafkaPayloadLog);
            throw ex;
        }
    }
}
