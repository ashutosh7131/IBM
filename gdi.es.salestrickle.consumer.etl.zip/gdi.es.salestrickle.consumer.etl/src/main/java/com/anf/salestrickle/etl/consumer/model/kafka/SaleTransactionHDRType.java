package com.anf.salestrickle.etl.consumer.model.kafka;

import com.fasterxml.jackson.annotation.*;
import lombok.Getter;
import lombok.Setter;

import javax.annotation.Generated;
import javax.validation.constraints.NotBlank;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Sale Transaction HDR Type
 */
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "sequenceNumber",
        "storeId",
        "rewardsEligiblePurchaseStore",
        "rewardsEligibleReturnStore",
        "workstationId",
        "businessDate",
        "storeType",
        "saleType",
        "reasonCode",
        "status",
        "employeeSaleId",
        "startTime",
        "endTime",
        "transactionStartTime",
        "transactionEndTime",
        "cashierId",
        "authorizerId",
        "taxExemptId",
        "subtotalAmount",
        "discountAmount",
        "taxAmount",
        "totalAmount",
        "grandTotalAmount",
        "filingCurrencyConversionFactor",
        "filingCurrencyCode",
        "origCurrencyCode",
        "storeCurrencyCode",
        "customerInfo",
        "tenderList",
        "originateEntryType",
        "originateStoreId",
        "originateWorkstationId",
        "originateSequenceNumber",
        "originateBusinessDate",
        "downstreamSystemList",
        "creditOfflineUpdate",
        "storeCountry",
        "pointsForVAT",
        "originateEnteredBy",
        "demandStore",
        "orderType",
        "orderNo",
        "invoiceNo",
        "webOrderID"
})
@Generated("jsonschema2pojo")
public class SaleTransactionHDRType {

    /**
     * Sales Transaction Sequence Number
     * (Required)
     */
    @JsonProperty("sequenceNumber")
    @JsonPropertyDescription("Sales Transaction Sequence Number")
    @NotBlank
    public String sequenceNumber;
    /**
     * Sales Transaction Sequence Number
     * (Required)
     */
    @JsonProperty("storeId")
    @JsonPropertyDescription("Sales Transaction Sequence Number")
    @NotBlank
    public String storeId;
    /**
     * rewards Eligible Purchase Store Flag
     * (Required)
     */
    @JsonProperty("rewardsEligiblePurchaseStore")
    @JsonPropertyDescription("rewards Eligible Purchase Store Flag")
    public boolean rewardsEligiblePurchaseStore;
    /**
     * rewards Eligible Return Store Flag
     * (Required)
     */
    @JsonProperty("rewardsEligibleReturnStore")
    @JsonPropertyDescription("rewards Eligible Return Store Flag")
    public boolean rewardsEligibleReturnStore;
    /**
     * Work Station Id
     * (Required)
     */
    @JsonProperty("workstationId")
    @JsonPropertyDescription("Work Station Id")
    @NotBlank
    public String workstationId;
    /**
     * business Date
     * (Required)
     */
    @JsonProperty("businessDate")
    @JsonPropertyDescription("business Date")
    @NotBlank
    public String businessDate;
    /**
     * Store Type
     */
    @JsonProperty("storeType")
    @JsonPropertyDescription("Store Type")
    @NotBlank
    public String storeType;
    /**
     * Sale Type
     */
    @JsonProperty("saleType")
    @JsonPropertyDescription("Sale Type")
    public String saleType;
    /**
     * Reason Code
     */
    @JsonProperty("reasonCode")
    @JsonPropertyDescription("Reason Code")
    public String reasonCode;
    /**
     * Sale Status
     */
    @JsonProperty("status")
    @JsonPropertyDescription("Sale Status")
    public String status;
    /**
     * Employee Sale Id
     */
    @JsonProperty("employeeSaleId")
    @JsonPropertyDescription("Employee Sale Id")
    public String employeeSaleId;
    /**
     * start time
     */
    @JsonProperty("startTime")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    @JsonPropertyDescription("start time")
    public Date startTime;
    /**
     * end Time
     */
    @JsonProperty("endTime")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    @JsonPropertyDescription("end Time")
    public Date endTime;
    /**
     * transaction start time
     */
    @JsonProperty("transactionStartTime")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    @JsonPropertyDescription("transaction start time")
    public Date transactionStartTime;
    /**
     * transaction end Time
     */
    @JsonProperty("transactionEndTime")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    @JsonPropertyDescription("transaction end Time")
    public Date transactionEndTime;
    /**
     * Store Cashier Id
     */
    @JsonProperty("cashierId")
    @JsonPropertyDescription("Store Cashier Id")
    public String cashierId;
    /**
     * Authorizer Id
     */
    @JsonProperty("authorizerId")
    @JsonPropertyDescription("Authorizer Id")
    public String authorizerId;
    /**
     * Tax Exempt Id
     */
    @JsonProperty("taxExemptId")
    @JsonPropertyDescription("Tax Exempt Id")
    public String taxExemptId;
    /**
     * Sub Total Amount
     */
    @JsonProperty("subtotalAmount")
    @JsonPropertyDescription("Sub Total Amount")
    public double subtotalAmount;
    /**
     * discount Amount
     */
    @JsonProperty("discountAmount")
    @JsonPropertyDescription("discount Amount")
    public double discountAmount;
    /**
     * Tax Amount
     */
    @JsonProperty("taxAmount")
    @JsonPropertyDescription("Tax Amount")
    public double taxAmount;
    /**
     * Total Amount
     */
    @JsonProperty("totalAmount")
    @JsonPropertyDescription("Total Amount")
    public Double totalAmount;
    /**
     * Grand Total Amount
     */
    @JsonProperty("grandTotalAmount")
    @JsonPropertyDescription("Grand Total Amount")
    public Double grandTotalAmount;
    /**
     * Currency Conversion Factor
     */
    @JsonProperty("filingCurrencyConversionFactor")
    @JsonPropertyDescription("Currency Conversion Factor")
    public Double filingCurrencyConversionFactor;
    /**
     * Filing Currency Code
     */
    @JsonProperty("filingCurrencyCode")
    @JsonPropertyDescription("Filing Currency Code")
    public String filingCurrencyCode;
    /**
     * Origin Currency Code
     */
    @JsonProperty("origCurrencyCode")
    @JsonPropertyDescription("Origin Currency Code")
    public String origCurrencyCode;
    /**
     * Store currency Code
     */
    @JsonProperty("storeCurrencyCode")
    @JsonPropertyDescription("Store currency Code")
    public String storeCurrencyCode;
    /**
     * Customer Info
     */
    @JsonProperty("customerInfo")
    @JsonPropertyDescription("Customer Info")
    public CustomerInfoType customerInfo;
    /**
     * Tender List
     */
    @JsonProperty("tenderList")
    @JsonPropertyDescription("Tender List")
    public List<TenderType> tenderList = null;
    /**
     * Orginate Entry Type
     */
    @JsonProperty("originateEntryType")
    @JsonPropertyDescription("Orginate Entry Type")
    public String originateEntryType;
    /**
     * Orig Store Id
     */
    @JsonProperty("originateStoreId")
    @JsonPropertyDescription("Orig Store Id")
    public String originateStoreId;
    /**
     * Originate Work Station Id
     */
    @JsonProperty("originateWorkstationId")
    @JsonPropertyDescription("Originate Work Station Id")
    public String originateWorkstationId;
    /**
     * Originate Seq NUmber
     */
    @JsonProperty("originateSequenceNumber")
    @JsonPropertyDescription("Originate Seq NUmber")
    public String originateSequenceNumber;
    /**
     * Originate Business Date
     */
    @JsonProperty("originateBusinessDate")
    @JsonPropertyDescription("Originate Business Date")
    public String originateBusinessDate;
    /**
     * Down Stream System List
     */
    @JsonProperty("downstreamSystemList")
    @JsonPropertyDescription("Down Stream System List")
    public List<String> downstreamSystemList = null;
    /**
     * Credit Offline Update Code
     */
    @JsonProperty("creditOfflineUpdate")
    @JsonPropertyDescription("Credit Offline Update Code")
    public CreditOfflineUpdate creditOfflineUpdate;
    /**
     * Store Country
     */
    @JsonProperty("storeCountry")
    @JsonPropertyDescription("Store Country")
    public String storeCountry;
    /**
     * points for VAT flag
     */
    @JsonProperty("pointsForVAT")
    @JsonPropertyDescription("points for VAT flag")
    public boolean pointsForVAT;
    /**
     * originate entered by
     */
    @JsonProperty("originateEnteredBy")
    @JsonPropertyDescription("originate entered by")
    public String originateEnteredBy;
    /**
     * demand store
     */
    @JsonProperty("demandStore")
    @JsonPropertyDescription("demand store")
    public String demandStore;
    /**
     * order type
     */
    @JsonProperty("orderType")
    @JsonPropertyDescription("order type")
    public String orderType;
    /**
     * order no
     */
    @JsonProperty("orderNo")
    @JsonPropertyDescription("order no")
    public String orderNo;
    /**
     * invoice no
     */
    @JsonProperty("invoiceNo")
    @JsonPropertyDescription("invoice no")
    public String invoiceNo;
    /**
     * webOrder id
     */
    @JsonProperty("webOrderID")
    @JsonPropertyDescription("webOrder id")
    public String webOrderID;


    /**
     * Credit Offline Update Code
     */
    @Generated("jsonschema2pojo")
    public enum CreditOfflineUpdate {

        EMPTY(""),
        Y("Y"),
        N("N");
        private final static Map<String, CreditOfflineUpdate> CONSTANTS = new HashMap<String, CreditOfflineUpdate>();

        static {
            for (CreditOfflineUpdate c : values()) {
                CONSTANTS.put(c.value, c);
            }
        }

        private final String value;

        CreditOfflineUpdate(String value) {
            this.value = value;
        }

        @JsonCreator
        public static CreditOfflineUpdate fromValue(String value) {
            CreditOfflineUpdate constant = CONSTANTS.get(value);
            if (constant == null) {
                throw new IllegalArgumentException(value);
            } else {
                return constant;
            }
        }

        @Override
        public String toString() {
            return this.value;
        }

        @JsonValue
        public String value() {
            return this.value;
        }

    }

}
