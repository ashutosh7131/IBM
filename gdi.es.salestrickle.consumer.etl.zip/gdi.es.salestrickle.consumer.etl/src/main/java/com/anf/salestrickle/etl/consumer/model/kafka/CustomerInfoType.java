package com.anf.salestrickle.etl.consumer.model.kafka;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

import javax.annotation.Generated;
import java.util.Date;


/**
 * Customer Info
 */
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "lastName",
        "firstName",
        "email",
        "phone",
        "addressInfo",
        "idType",
        "idSwiped",
        "encryptedId",
        "customerLinkType",
        "customerLinkCode",
        "customerReturnLinkCode",
        "checkForRewardsAccount",
        "shipToAddressInfo",
        "shipToTaxAreaId",
        "shippingTransportMode",
        "shippingDate",
        "shippingDeliveryTerms",
        "shippingOverrideReason",
        "eReceiptIndicator",
        "marketingEmailIndicator",
        "loyaltyPartner",
        "customerWebStoreId"
})
@Generated("jsonschema2pojo")
public class CustomerInfoType {

    /**
     * Last Name
     */
    @JsonProperty("lastName")
    @JsonPropertyDescription("Last Name")
    public String lastName;
    /**
     * First Name
     */
    @JsonProperty("firstName")
    @JsonPropertyDescription("First Name")
    public String firstName;
    /**
     * Email Address
     */
    @JsonProperty("email")
    @JsonPropertyDescription("Email Address")
    public String email;
    /**
     * Phone Number
     */
    @JsonProperty("phone")
    @JsonPropertyDescription("Phone Number")
    public String phone;
    /**
     * Address information.
     */
    @JsonProperty("addressInfo")
    @JsonPropertyDescription("Address information.")
    public AddressInfo addressInfo;
    /**
     * Id Type
     */
    @JsonProperty("idType")
    @JsonPropertyDescription("Id Type")
    public String idType;
    /**
     * Id Swiped Flag
     */
    @JsonProperty("idSwiped")
    @JsonPropertyDescription("Id Swiped Flag")
    public Boolean idSwiped;
    /**
     * Encrypted Id
     */
    @JsonProperty("encryptedId")
    @JsonPropertyDescription("Encrypted Id")
    public String encryptedId;
    /**
     * Customer Link Type
     */
    @JsonProperty("customerLinkType")
    @JsonPropertyDescription("Customer Link Type")
    public String customerLinkType;
    /**
     * Customer Link Code
     */
    @JsonProperty("customerLinkCode")
    @JsonPropertyDescription("Customer Link Code")
    public String customerLinkCode;
    /**
     * Customer Returns Link Code
     */
    @JsonProperty("customerReturnLinkCode")
    @JsonPropertyDescription("Customer Returns Link Code")
    public String customerReturnLinkCode;
    /**
     * Check Rewards Account Flag
     */
    @JsonProperty("checkForRewardsAccount")
    @JsonPropertyDescription("Check Rewards Account Flag")
    public boolean checkForRewardsAccount;
    /**
     * Address information.
     */
    @JsonProperty("shipToAddressInfo")
    @JsonPropertyDescription("Address information.")
    public AddressInfo shipToAddressInfo;
    /**
     * Ship To Tax Area Id
     */
    @JsonProperty("shipToTaxAreaId")
    @JsonPropertyDescription("Ship To Tax Area Id")
    public Integer shipToTaxAreaId;
    /**
     * Shipping Transport Mode
     */
    @JsonProperty("shippingTransportMode")
    @JsonPropertyDescription("Shipping Transport Mode")
    public String shippingTransportMode;
    /**
     * Shipping Date
     */
    @JsonProperty("shippingDate")
    @JsonPropertyDescription("Shipping Date")
    public Date shippingDate;
    /**
     * Shipping Delivery terms
     */
    @JsonProperty("shippingDeliveryTerms")
    @JsonPropertyDescription("Shipping Delivery terms")
    public String shippingDeliveryTerms;
    /**
     * Shipping Override Reason
     */
    @JsonProperty("shippingOverrideReason")
    @JsonPropertyDescription("Shipping Override Reason")
    public String shippingOverrideReason;
    /**
     * Ereceipt Indicator
     */
    @JsonProperty("eReceiptIndicator")
    @JsonPropertyDescription("Ereceipt Indicator")
    public Integer eReceiptIndicator;
    /**
     * Marketing Email Indicator
     */
    @JsonProperty("marketingEmailIndicator")
    @JsonPropertyDescription("Marketing Email Indicator")
    public Integer marketingEmailIndicator;
    /**
     * loyalty Partner
     */
    @JsonProperty("loyaltyPartner")
    @JsonPropertyDescription("loyalty Partner")
    public String loyaltyPartner;

    @JsonProperty("customerWebStoreId")
    @JsonPropertyDescription("Customer Web Store Id")
    public String customerWebStoreId;


}
