package com.anf.salestrickle.etl.consumer.service;

import com.anf.logservice.LoggingService;
import com.anf.logservice.models.LogRequest;
import com.anf.salestrickle.etl.consumer.dao.ETLUpsertDao;
import com.anf.salestrickle.etl.consumer.model.kafka.SaleTransactionHDRType;
import com.anf.salestrickle.etl.consumer.model.kafka.SalesTransactions;
import com.anf.salestrickle.etl.consumer.util.mappers.ETLDBTableEntitiesMapper;
import com.anf.salestrickle.etl.consumer.util.validators.NullConstraintMessageValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.constraints.NotNull;
import java.util.*;

import static com.anf.salestrickle.etl.consumer.data.Constants.*;

@Service

public class ETLUpsertService {

    @Autowired
    private ETLDBTableEntitiesMapper tableEntitiesMapper;

    @Autowired
    private ETLUpsertDao etlUpsertDao;

    @Autowired
    private LoggingService loggingService;

    @Autowired
    private NullConstraintMessageValidator nullConstraintMessageValidator;

    private void setOperationTypeInMap(@NotNull SaleTransactionHDRType saleTransactionHDRType, Map<String, Object> map) {
        if (null != saleTransactionHDRType && !containsLoyaltyPlus(saleTransactionHDRType)) {
            if (SaleTransactionHDRType.CreditOfflineUpdate.Y.equals(saleTransactionHDRType.getCreditOfflineUpdate())) {
                map.put(OPERATION_TYPE, UPDATE);
            } else {
                map.put(OPERATION_TYPE, INSERT);
            }
        } else {
            map.put(OPERATION_TYPE, INVALID);
        }
    }

    private boolean containsLoyaltyPlus(@NotNull SaleTransactionHDRType saleTransactionHDRType) {
        boolean isLoyaltyPlus = false;
        List<String> downstreamSystems = saleTransactionHDRType.getDownstreamSystemList();
        if (null != downstreamSystems) {
            for (String system :
                    downstreamSystems) {
                if (LOYALTYPLUS.equalsIgnoreCase(system)) {
                    isLoyaltyPlus = true;
                    break;
                }
            }
        }
        return isLoyaltyPlus;
    }

    private void addMandatoryFieldsInMap(SaleTransactionHDRType saleTransactionHDRType, Map<String, Object> map) {
        map.put(STORE_ID, saleTransactionHDRType.getStoreId());
        map.put(WORKSTATION_ID, saleTransactionHDRType.getWorkstationId());
        map.put(BUSINESS_DATE, saleTransactionHDRType.getBusinessDate());
        map.put(SEQUENCE_NUMBER, saleTransactionHDRType.getSequenceNumber());
    }

    public void saveDataToETLDB(@NotNull SalesTransactions salesTransactions, String jsonMessage) throws Exception {
        loggingService.log(LogRequest.debug(UUID.randomUUID(), "VALIDATING MESSAGE :: " + jsonMessage).defaultLogger());
        Set<String> violatedStringTypeNullFields = nullConstraintMessageValidator.validateMessage(salesTransactions);
        Map<String, Object> map = new HashMap<String, Object>();
        this.setOperationTypeInMap(salesTransactions.getSaleTransactionMessage().getSaleTransactionHDRType(), map);
        String operationType = (String) map.get(OPERATION_TYPE);
        if (!violatedStringTypeNullFields.isEmpty() || INVALID.equalsIgnoreCase(operationType)) {
            loggingService.log(LogRequest.error(salesTransactions.getCorrelationId(),
                            new Exception("MessageValidation Failed :: Either Operation is Invalid or Mandatory String Field is Missing."),
                            " Operation Type - " + operationType + "\t Missing Field List - " + violatedStringTypeNullFields)
                    .defaultLogger());
        } else {
            map.put(JSON_MESSAGE_STRING, jsonMessage);
            this.addMandatoryFieldsInMap(salesTransactions.getSaleTransactionMessage().getSaleTransactionHDRType(), map);
            tableEntitiesMapper.mapTableEntities(salesTransactions.getSaleTransactionMessage(), map);
            etlUpsertDao.saveAllBatch(salesTransactions, map);
        }
    }
}
