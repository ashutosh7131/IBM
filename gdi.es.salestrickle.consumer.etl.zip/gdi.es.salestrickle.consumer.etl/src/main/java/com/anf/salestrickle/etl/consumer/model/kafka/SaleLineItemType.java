package com.anf.salestrickle.etl.consumer.model.kafka;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

import javax.annotation.Generated;
import javax.validation.constraints.NotNull;
import java.util.List;


/**
 * Sale Transaction HDR Type
 */
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "lineItemNumber",
        "itemId",
        "origItemId",
        "quantity",
        "nonMerch",
        "ticketAmount",
        "sellAmount",
        "discountAmount",
        "taxAmount",
        "extendedAmount",
        "voided",
        "giftReceiptPrinted",
        "maskedGiftCardId",
        "taxGroupId",
        "origStoreId",
        "origBusinessDay",
        "origWorkstationId",
        "origSequenceNumber",
        "origLineItemNumber",
        "origReceiptEntryMethod",
        "origReceiptType",
        "entryMethod",
        "returnReasonCode",
        "priceOverride",
        "priceOverrideReasonCode",
        "taxOverride",
        "giftCardRequestType",
        "encryptedGiftCardNumber",
        "shippingIntrastatCode",
        "shippingMass",
        "shippingCountryOfOrigin",
        "shippingFromCountry",
        "discountLineItemList",
        "taxLineItemList",
        "priceTypeCode",
        "originateStockOutReasonCode",
        "fulfillStoreID",
        "omniCode",
        "pickupStoreId",
        "fulfillStoreAssociateId",
        "demStoreId",
        "demWorkstationId",
        "demSequenceNumber",
        "demBusinessDate"
})
@Generated("jsonschema2pojo")
public class SaleLineItemType {

    /**
     * Sales Transaction Sequence Number
     * (Required)
     */
    @JsonProperty("lineItemNumber")
    @JsonPropertyDescription("Sales Transaction Sequence Number")
    @NotNull
    public double lineItemNumber;
    /**
     * Item Id
     */
    @JsonProperty("itemId")
    @JsonPropertyDescription("Item Id")
    public String itemId;
    /**
     * Orig Item Id
     */
    @JsonProperty("origItemId")
    @JsonPropertyDescription("Orig Item Id")
    public String origItemId;
    /**
     * Quantity
     * (Required)
     */
    @JsonProperty("quantity")
    @JsonPropertyDescription("Quantity")
    public double quantity;
    /**
     * Non Merch Flag
     */
    @JsonProperty("nonMerch")
    @JsonPropertyDescription("Non Merch Flag")
    public boolean nonMerch;
    /**
     * Ticket Amount
     */
    @JsonProperty("ticketAmount")
    @JsonPropertyDescription("Ticket Amount")
    public double ticketAmount;
    /**
     * Sell Amount
     */
    @JsonProperty("sellAmount")
    @JsonPropertyDescription("Sell Amount")
    public double sellAmount;
    /**
     * Discount Amount
     */
    @JsonProperty("discountAmount")
    @JsonPropertyDescription("Discount Amount")
    public double discountAmount;
    /**
     * Tax Amount
     */
    @JsonProperty("taxAmount")
    @JsonPropertyDescription("Tax Amount")
    public double taxAmount;
    /**
     * Entended Amount
     */
    @JsonProperty("extendedAmount")
    @JsonPropertyDescription("Entended Amount")
    public double extendedAmount;
    /**
     * Voided status flag
     */
    @JsonProperty("voided")
    @JsonPropertyDescription("Voided status flag")
    public boolean voided;
    /**
     * Gift Receipt Printed Flag
     */
    @JsonProperty("giftReceiptPrinted")
    @JsonPropertyDescription("Gift Receipt Printed Flag")
    public boolean giftReceiptPrinted;
    /**
     * Masked Gift Card Id
     */
    @JsonProperty("maskedGiftCardId")
    @JsonPropertyDescription("Masked Gift Card Id")
    public String maskedGiftCardId;
    /**
     * Tax Group Id
     */
    @JsonProperty("taxGroupId")
    @JsonPropertyDescription("Tax Group Id")
    public String taxGroupId;
    /**
     * Orig Store Id
     */
    @JsonProperty("origStoreId")
    @JsonPropertyDescription("Orig Store Id")
    public String origStoreId;
    /**
     * Orig Business Day
     */
    @JsonProperty("origBusinessDay")
    @JsonPropertyDescription("Orig Business Day")
    public String origBusinessDay;
    /**
     * orig Workstation id
     */
    @JsonProperty("origWorkstationId")
    @JsonPropertyDescription("orig Workstation id")
    public String origWorkstationId;
    /**
     * Orig Sequence NUmber
     */
    @JsonProperty("origSequenceNumber")
    @JsonPropertyDescription("Orig Sequence Number")
    public Double origSequenceNumber;
    /**
     * Orig Line Item Number
     */
    @JsonProperty("origLineItemNumber")
    @JsonPropertyDescription("Orig Line Item Number")
    public Double origLineItemNumber;
    /**
     * Entry Method Code
     */
    @JsonProperty("origReceiptEntryMethod")
    @JsonPropertyDescription("Entry Method Code")
    public String origReceiptEntryMethod;
    /**
     * Orig Receipt Type
     */
    @JsonProperty("origReceiptType")
    @JsonPropertyDescription("Orig Receipt Type")
    public String origReceiptType;
    /**
     * Entry Method Code
     */
    @JsonProperty("entryMethod")
    @JsonPropertyDescription("Entry Method Code")
    public String entryMethod;
    /**
     * Return Reason Code
     */
    @JsonProperty("returnReasonCode")
    @JsonPropertyDescription("Return Reason Code")
    public String returnReasonCode;
    /**
     * Origin Currency Code
     */
    @JsonProperty("priceOverride")
    @JsonPropertyDescription("Origin Currency Code")
    public boolean priceOverride;
    /**
     * Prie Override Reason Code
     */
    @JsonProperty("priceOverrideReasonCode")
    @JsonPropertyDescription("Prie Override Reason Code")
    public String priceOverrideReasonCode;
    /**
     * Tax Override
     */
    @JsonProperty("taxOverride")
    @JsonPropertyDescription("Tax Override")
    public boolean taxOverride;
    /**
     * Gift Card Request Type
     */
    @JsonProperty("giftCardRequestType")
    @JsonPropertyDescription("Gift Card Request Type")
    public String giftCardRequestType;
    /**
     * Encrypted Gift Card Number
     */
    @JsonProperty("encryptedGiftCardNumber")
    @JsonPropertyDescription("Encrypted Gift Card Number")
    public String encryptedGiftCardNumber;
    /**
     * Shipping Intra Stat Code
     */
    @JsonProperty("shippingIntrastatCode")
    @JsonPropertyDescription("Shipping Intra Stat Code")
    public String shippingIntrastatCode;
    /**
     * Shipping Mass
     */
    @JsonProperty("shippingMass")
    @JsonPropertyDescription("Shipping Mass")
    public String shippingMass;
    /**
     * Shipping Country Origin
     */
    @JsonProperty("shippingCountryOfOrigin")
    @JsonPropertyDescription("Shipping Country Origin")
    public String shippingCountryOfOrigin;
    /**
     * Shipping from Country
     */
    @JsonProperty("shippingFromCountry")
    @JsonPropertyDescription("Shipping from Country")
    public String shippingFromCountry;
    /**
     * Discount Line Item List
     */
    @JsonProperty("discountLineItemList")
    @JsonPropertyDescription("Discount Line Item List")
    public List<DiscountLineItemType> discountLineItemList = null;
    /**
     * Tax Line Item List
     */
    @JsonProperty("taxLineItemList")
    @JsonPropertyDescription("Tax Line Item List")
    public List<TaxLineItemType> taxLineItemList = null;
    /**
     * Priec Type Code
     */
    @JsonProperty("priceTypeCode")
    @JsonPropertyDescription("Priec Type Code")
    public Double priceTypeCode;
    /**
     * Originate Stock Out Reason Code
     */
    @JsonProperty("originateStockOutReasonCode")
    @JsonPropertyDescription("Originate Stock Out Reason Code")
    public Double originateStockOutReasonCode;
    /**
     * Fulfill Store Id
     */
    @JsonProperty("fulfillStoreID")
    @JsonPropertyDescription("Fulfill Store Id")
    public String fulfillStoreID;
    /**
     * Omni Code
     */
    @JsonProperty("omniCode")
    @JsonPropertyDescription("Omni Code")
    public String omniCode;
    /**
     * pickup store Id
     */
    @JsonProperty("pickupStoreId")
    @JsonPropertyDescription("pickup store Id")
    public String pickupStoreId;
    /**
     * fulfill store associate Id
     */
    @JsonProperty("fulfillStoreAssociateId")
    @JsonPropertyDescription("fulfill store associate Id")
    public String fulfillStoreAssociateId;
    /**
     * demStoreId
     */
    @JsonProperty("demStoreId")
    @JsonPropertyDescription("demStoreId")
    public String demStoreId;
    /**
     * demWorkstationId
     */
    @JsonProperty("demWorkstationId")
    @JsonPropertyDescription("demWorkstationId")
    public String demWorkstationId;
    /**
     * demSequenceNumber
     */
    @JsonProperty("demSequenceNumber")
    @JsonPropertyDescription("demSequenceNumber")
    public String demSequenceNumber;
    /**
     * demBusinessDate
     */
    @JsonProperty("demBusinessDate")
    @JsonPropertyDescription("demBusinessDate")
    public String demBusinessDate;

}
