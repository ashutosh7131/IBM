package com.anf.salestrickle.etl.consumer.util.mappers;

import com.anf.salestrickle.etl.consumer.model.kafka.SaleTransactionMessage;
import com.anf.salestrickle.etl.consumer.model.kafka.TenderType;
import com.anf.salestrickle.etl.consumer.model.tables.TenderEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.anf.salestrickle.etl.consumer.data.Constants.*;

@Component
public class TenderMapper {

    public void mapToTenderEntity(SaleTransactionMessage saleTransactionMessage, Map<String, Object> map) {
        List<TenderType> tenderTypeList = saleTransactionMessage.getSaleTransactionHDRType().getTenderList();
        List<TenderEntity> tenderEntityList = new ArrayList<TenderEntity>();
        for (TenderType tenderType :
                tenderTypeList) {
            tenderEntityList.add(this.getTenderEntity(saleTransactionMessage, tenderType, map));
        }
        if (!tenderEntityList.isEmpty()) {
            map.put(TENDER_ENTITY_LIST, tenderEntityList);
        }
    }

    private TenderEntity getTenderEntity(SaleTransactionMessage saleTransactionMessage, TenderType tenderType, Map<String, Object> map) {
        TenderEntity tenderEntity = new TenderEntity();
        tenderEntity.setStoreId((String) map.get(STORE_ID));
        tenderEntity.setWorkstationId((String) map.get(WORKSTATION_ID));
        tenderEntity.setBusinessDate((String) map.get(BUSINESS_DATE));
        tenderEntity.setSequenceNumber((String) map.get(SEQUENCE_NUMBER));
        tenderEntity.setTenderNumber(tenderType.getTenderNumber());
        tenderEntity.setTenderAmount(tenderType.getTenderAmount());
        tenderEntity.setAccountName(tenderType.getAccountName());
        tenderEntity.setTenderType(tenderType.getTenderType());
        tenderEntity.setTenderTypeId(tenderType.getTenderTypeId());
        tenderEntity.setCardAuthMethod(tenderType.getCardAuthMethod());
        tenderEntity.setCardAuthReturnCode(tenderType.getCardAuthReturnCode());
        tenderEntity.setCardEntryMode(tenderType.getCardEntryMode());
        tenderEntity.setEncryptedExpDate(tenderType.getEncryptedExpDate());
        tenderEntity.setEncryptedCardNumber(tenderType.getEncryptedCardNumber());
        tenderEntity.setMaskedCardNumber(tenderType.getMaskedCardNumber());
        tenderEntity.setEncryptedCheckRoutingNumber(tenderType.getEncryptedCheckRoutingNumber());
        tenderEntity.setEncryptedCheckAccountNumber(tenderType.getEncryptedCheckAccountNumber());
        tenderEntity.setHashedCardNumber(tenderType.getHashedCardNumber());
        tenderEntity.setLineItemNumber(tenderType.getLineItemNumber());
        tenderEntity.setStoreCurrencyCode(saleTransactionMessage.getSaleTransactionHDRType().getStoreCurrencyCode());
        tenderEntity.setTenderExchangeRate(tenderType.getTenderExchangeRate());
        tenderEntity.setForeignTenderCurrencyCode(tenderType.getForeignTenderCurrencyCode());
        tenderEntity.setForeignTenderAmount(tenderType.getForeignTenderAmount());
        tenderEntity.setEncryptionType(mapEncryptionType(tenderType.getEncryptionType()));
        return tenderEntity;
    }


    private String mapEncryptionType(TenderType.EncryptionType encryptionType) {
        String type = null;
        if (null != encryptionType && encryptionType.value().length() <= 1) {
            type = encryptionType.value();
        }
        return type;
    }
}
