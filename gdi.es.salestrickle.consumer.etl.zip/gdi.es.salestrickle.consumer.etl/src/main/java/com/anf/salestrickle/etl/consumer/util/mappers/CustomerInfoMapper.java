package com.anf.salestrickle.etl.consumer.util.mappers;

import com.anf.salestrickle.etl.consumer.model.kafka.AddressInfo;
import com.anf.salestrickle.etl.consumer.model.kafka.CustomerInfoType;
import com.anf.salestrickle.etl.consumer.model.kafka.SaleTransactionMessage;
import com.anf.salestrickle.etl.consumer.model.tables.CustomerInfoEntity;
import org.springframework.stereotype.Component;

import java.util.Map;

import static com.anf.salestrickle.etl.consumer.data.Constants.*;

@Component
public class CustomerInfoMapper {

    public void mapToCustomerInfoEntity(SaleTransactionMessage saleTransactionMessage, Map<String, Object> map) {
        CustomerInfoType customerInfoType = saleTransactionMessage.getSaleTransactionHDRType().getCustomerInfo();
        if (null != customerInfoType) {
            CustomerInfoEntity customerInfoEntity = new CustomerInfoEntity();
            customerInfoEntity.setStoreId((String) map.get(STORE_ID));
            customerInfoEntity.setWorkstationId((String) map.get(WORKSTATION_ID));
            customerInfoEntity.setBusinessDate((String) map.get(BUSINESS_DATE));
            customerInfoEntity.setSequenceNumber(Double.valueOf((String) map.get(SEQUENCE_NUMBER)));
            customerInfoEntity.setLastName(customerInfoType.getLastName());
            customerInfoEntity.setFirstName(customerInfoType.getFirstName());
            customerInfoEntity.setEmail(customerInfoType.getEmail());
            customerInfoEntity.setPhone(customerInfoType.getPhone());
            mapAddressDetail(customerInfoEntity, customerInfoType);
            customerInfoEntity.setIdType(customerInfoType.getIdType());
            customerInfoEntity.setIdSwiped(this.getIdSwipedInCharacter(customerInfoType.getIdSwiped()));
            customerInfoEntity.setEncryptedId(customerInfoType.getEncryptedId());
            customerInfoEntity.setCustomerLinkType(customerInfoType.getCustomerLinkType());
            customerInfoEntity.setCustomerLinkCode(customerInfoType.getCustomerLinkCode());
            mapShippingAddressDetail(customerInfoEntity, customerInfoType);
            customerInfoEntity.setShipToTaxAreaId(customerInfoType.getShipToTaxAreaId());
            customerInfoEntity.setShippingTransportMode(customerInfoType.getShippingTransportMode());
            customerInfoEntity.setShippingDate(customerInfoType.getShippingDate());
            customerInfoEntity.setShippingDeliveryTerms(customerInfoType.getShippingDeliveryTerms());
            customerInfoEntity.setEReceiptIndicator(customerInfoType.getEReceiptIndicator());
            customerInfoEntity.setMarketingEmailIndicator(customerInfoType.getMarketingEmailIndicator());
            customerInfoEntity.setShippingOverrideReason(customerInfoType.getShippingOverrideReason());
            map.put(CUSTOMER_INFO_ENTITY, customerInfoEntity);
        }
    }

    private void mapAddressDetail(CustomerInfoEntity customerInfoEntity, CustomerInfoType customerInfoType) {
        AddressInfo addressInfo = customerInfoType.getAddressInfo();
        if (null != addressInfo) {
            customerInfoEntity.setAddress1(addressInfo.getAddress1());
            customerInfoEntity.setAddress2(addressInfo.getAddress2());
            customerInfoEntity.setCity(addressInfo.getCity());
            customerInfoEntity.setState(addressInfo.getState());
            customerInfoEntity.setZipCode(addressInfo.getZipCode());
            customerInfoEntity.setZipCodeExt(addressInfo.getZipCodeExt());
            customerInfoEntity.setCountry(addressInfo.getCountry());
        }
    }

    private void mapShippingAddressDetail(CustomerInfoEntity customerInfoEntity, CustomerInfoType customerInfoType) {
        AddressInfo shipToAddressInfo = customerInfoType.getShipToAddressInfo();
        if (null != shipToAddressInfo) {
            customerInfoEntity.setShipToAddress1(shipToAddressInfo.getAddress1());
            customerInfoEntity.setShipToAddress2(shipToAddressInfo.getAddress2());
            customerInfoEntity.setShipToCity(shipToAddressInfo.getCity());
            customerInfoEntity.setShipToState(shipToAddressInfo.getState());
            customerInfoEntity.setShipToZipCode(shipToAddressInfo.getZipCode());
            customerInfoEntity.setShipToZipCodeExt(shipToAddressInfo.getZipCodeExt());
            customerInfoEntity.setShipToCountry(shipToAddressInfo.getCountry());
        }
    }

    private Character getIdSwipedInCharacter(Boolean idSwiped) {
        Character character = null;
        if (null == idSwiped) {
            return character;
        }
        if (idSwiped.booleanValue()) {
            character = CHARACTER_Y;
        } else {
            character = CHARACTER_N;
        }

        return character;
    }
}
