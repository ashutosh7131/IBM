package com.anf.salestrickle.etl.consumer.model.tables;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SaleLineItemEntity {

    private String storeId;
    private String workstationId;
    private String businessDate;
    private String sequenceNumber;
    private double lineItemNumber;
    private String itemId;
    private String origItemId;
    private double quantity;
    private char nonMerch;
    private double ticketAmount;
    private double discountAmount;
    private double sellAmount;
    private double taxAmount;
    private char voided;
    private char giftReceiptPrinted;
    private String maskedGiftCardId;
    private String taxGroupId;
    private String origStoreId;
    private String origWorkstationId;
    private String origBusinessDay;
    private Double origSequenceNumber;
    private Double origLineItemNumber;
    private String origReceiptEntryMethod;
    private String origReceiptType;
    private String entryMethod;
    private String returnReasonCode;
    private char priceOverride;
    private String priceOverrideReasonCode;
    private char taxOverride;
    private String giftCardRequestType;
    private String encryptedGiftCardNumber;
    private String shippingIntrastatCode;
    private String shippingMass;
    private String shippingCountryOfOrigin;
    private String shippingFromCountry;
    private Double extendedAmount;
    private Double originateStockOutReasonCode;
    private Double priceTypeCode;
    private String fulfillStoreID;
    private String omniCode;
    private String pickupStoreId;
    private String fulfillStoreAssociateId;
    private String demStoreId;
    private String demWorkstationId;
    private String demSequenceNumber;
    private String demBusinessDate;
}
