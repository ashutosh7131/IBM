package com.anf.salestrickle.etl.consumer.data;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Constants {
    public static final String FAULT_CODE = "ANF-500";
    public static final String CORRELATION_ID_HEADER = "Correlation-ID";
    public static final String COUNT_HEADER = "Count";
    public static final String RECORDS_EFFECTED_HEADER = "Records-Effected";
    public static final String CONTENT_LANGUAGE_HEADER = "Content-Language";
    public static final String CONTENT_LANGUAGE_HEADER_VALUE = "en-US";

    public static final String LOG_ENTRY_START = ":::SALES LOYALTY CONSUMER";

    public static final String LOYALTYPLUS = "LOYALTYPLUS";
    public static final String OPERATION_TYPE = "Operation_Type";
    public static final String INSERT = "INSERT";
    public static final String UPDATE = "UPDATE";
    public static final String INVALID = "INVALID";
    public static final String STORE_ID = "STORE_ID";
    public static final String WORKSTATION_ID = "WORKSTATION_ID";
    public static final String BUSINESS_DATE = "BUSINESS_DATE";
    public static final String SEQUENCE_NUMBER = "SEQUENCE_NUMBER";
    public static final String STORE_TYPE = "STORE_TYPE";
    public static final String TAX_AUTHORITY = "TAX_AUTHORITY";
    public static final String JSON_MESSAGE_STRING = "JSON_MESSAGE_STRING";
    public static final String TENDER_ENTITY_LIST = "TENDER_ENTITY_LIST";
    public static final String SALE_TRANSACTION_ENTITY = "SALE_TRANSACTION_ENTITY";
    public static final String CUSTOMER_INFO_ENTITY = "CUSTOMER_INFO_ENTITY";
    public static final String SALE_LINE_ITEM_ENTITY_LIST = "SALE_LINE_ITEM_ENTITY_LIST";
    public static final String TAX_LINE_ITEM_ENTITY_LIST = "TAX_LINE_ITEM_ENTITY_LIST";
    public static final String DISCOUNT_LINE_ITEM_ENTITY_LIST = "DISCOUNT_LINE_ITEM_ENTITY_LIST";

    public static final char CHARACTER_Y = 'Y';
    public static final char CHARACTER_N = 'N';
    public static final char CHARACTER_0 = '0';
}