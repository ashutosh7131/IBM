package com.anf.salestrickle.etl.consumer.model.tables;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class CustomerInfoEntity {

    private String storeId;
    private String workstationId;
    private String businessDate;
    private Double sequenceNumber;
    private String lastName;
    private String firstName;
    private String email;
    private String phone;
    private String address1;
    private String address2;
    private String city;
    private String state;
    private String zipCode;
    private String zipCodeExt;
    private String country;
    private String idType;
    private Character idSwiped;
    private String encryptedId;
    private String customerLinkType;
    private String customerLinkCode;
    private String shipToAddress1;
    private String shipToAddress2;
    private String shipToCity;
    private String shipToState;
    private String shipToZipCode;
    private String shipToZipCodeExt;
    private String shipToCountry;
    private Integer shipToTaxAreaId;
    private String shippingTransportMode;
    private Date shippingDate;
    private String shippingDeliveryTerms;
    private Integer eReceiptIndicator;
    private Integer marketingEmailIndicator;
    private String shippingOverrideReason;
}
