package com.anf.salestrickle.etl.consumer.util.mappers;

import com.anf.logservice.LoggingService;
import com.anf.logservice.models.LogRequest;
import com.anf.salestrickle.etl.consumer.model.kafka.SaleTransactionMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.UUID;

import static com.anf.salestrickle.etl.consumer.data.Constants.INSERT;
import static com.anf.salestrickle.etl.consumer.data.Constants.OPERATION_TYPE;

@Component
public class ETLDBTableEntitiesMapper {

    @Autowired
    private SaleLineItemMapper saleLineItemMapper;

    @Autowired
    private SaleTransactionMapper saleTransactionMapper;

    @Autowired
    private TenderMapper tenderMapper;

    @Autowired
    private LoggingService loggingService;

    public void mapTableEntities(SaleTransactionMessage saleTransactionMessage, Map<String, Object> map) {

        loggingService.log(LogRequest.debug(UUID.randomUUID(), "MAPPING TO TABLE ENTITIES :: " + saleTransactionMessage.toString()).defaultLogger());

        tenderMapper.mapToTenderEntity(saleTransactionMessage, map);

        String operationType = (String) map.get(OPERATION_TYPE);
        if (INSERT.equals(operationType)) {
            saleTransactionMapper.mapToSaleTransactionEntity(saleTransactionMessage, map);
            saleLineItemMapper.mapToSaleLineItemEntity(saleTransactionMessage, map);
        }
    }
}
