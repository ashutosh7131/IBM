package com.anf.salestrickle.etl.consumer.util.mappers;

import com.anf.salestrickle.etl.consumer.model.kafka.SaleLineItemType;
import com.anf.salestrickle.etl.consumer.model.kafka.SaleTransactionMessage;
import com.anf.salestrickle.etl.consumer.model.tables.DiscountLineItemEntity;
import com.anf.salestrickle.etl.consumer.model.tables.SaleLineItemEntity;
import com.anf.salestrickle.etl.consumer.model.tables.TaxLineItemEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.anf.salestrickle.etl.consumer.data.Constants.*;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Component
public class SaleLineItemMapper {

    @Autowired
    private TaxLineItemMapper taxLineItemMapper;

    @Autowired
    private DiscountLineItemMapper discountLineItemMapper;

    public void mapToSaleLineItemEntity(SaleTransactionMessage saleTransactionMessage, Map<String, Object> map) {
        List<SaleLineItemType> saleLineItemTypeList = saleTransactionMessage.getSaleTransactionItems();
        if (null != saleLineItemTypeList && !saleLineItemTypeList.isEmpty()) {
            List<SaleLineItemEntity> saleLineItemEntityList = new ArrayList<SaleLineItemEntity>();
            List<TaxLineItemEntity> taxLineItemEntityList = new ArrayList<TaxLineItemEntity>();
            List<DiscountLineItemEntity> discountLineItemEntityList = new ArrayList<DiscountLineItemEntity>();
            for (SaleLineItemType saleLineItemType :
                    saleLineItemTypeList) {
                saleLineItemEntityList.add(mapToSaleLineItemEntity(map, saleLineItemType, taxLineItemEntityList, discountLineItemEntityList));
            }
            if (!saleLineItemEntityList.isEmpty()) {
                map.put(SALE_LINE_ITEM_ENTITY_LIST, saleLineItemEntityList);
                if (!taxLineItemEntityList.isEmpty()) {
                    map.put(TAX_LINE_ITEM_ENTITY_LIST, taxLineItemEntityList);
                }
                if (!discountLineItemEntityList.isEmpty()) {
                    map.put(DISCOUNT_LINE_ITEM_ENTITY_LIST, discountLineItemEntityList);
                }
            }
        }
    }

    private SaleLineItemEntity mapToSaleLineItemEntity(Map<String, Object> map, SaleLineItemType saleLineItemType, List<TaxLineItemEntity> taxLineItemEntityList, List<DiscountLineItemEntity> discountLineItemEntityList) {

        SaleLineItemEntity saleLineItemEntity = new SaleLineItemEntity();
        saleLineItemEntity.setStoreId((String) map.get(STORE_ID));
        saleLineItemEntity.setWorkstationId((String) map.get(WORKSTATION_ID));
        saleLineItemEntity.setBusinessDate((String) map.get(BUSINESS_DATE));
        saleLineItemEntity.setSequenceNumber((String) map.get(SEQUENCE_NUMBER));
        saleLineItemEntity.setLineItemNumber(saleLineItemType.getLineItemNumber());
        saleLineItemEntity.setItemId(saleLineItemType.getItemId());
        saleLineItemEntity.setOrigItemId(saleLineItemType.getOrigItemId());
        saleLineItemEntity.setQuantity(saleLineItemType.getQuantity());
        saleLineItemEntity.setNonMerch(mapBooleanToChar(saleLineItemType.isNonMerch()));
        saleLineItemEntity.setTicketAmount(saleLineItemType.getTicketAmount());
        saleLineItemEntity.setDiscountAmount(saleLineItemType.getDiscountAmount());
        saleLineItemEntity.setSellAmount(saleLineItemType.getSellAmount());
        saleLineItemEntity.setTaxAmount(saleLineItemType.getTaxAmount());
        saleLineItemEntity.setVoided(mapBooleanToChar(saleLineItemType.isVoided()));
        saleLineItemEntity.setGiftReceiptPrinted(mapBooleanToChar(saleLineItemType.isGiftReceiptPrinted()));
        saleLineItemEntity.setMaskedGiftCardId(saleLineItemType.getMaskedGiftCardId());
        saleLineItemEntity.setTaxGroupId(saleLineItemType.getTaxGroupId());
        saleLineItemEntity.setOrigStoreId(saleLineItemType.getOrigStoreId());
        saleLineItemEntity.setOrigWorkstationId(saleLineItemType.getOrigWorkstationId());
        saleLineItemEntity.setOrigBusinessDay(saleLineItemType.getOrigBusinessDay());
        saleLineItemEntity.setOrigSequenceNumber(saleLineItemType.getOrigSequenceNumber());
        saleLineItemEntity.setOrigLineItemNumber(saleLineItemType.getOrigLineItemNumber());
        saleLineItemEntity.setOrigReceiptEntryMethod(mapOriginReceiptEntryMethod(saleLineItemType.getOrigReceiptEntryMethod()));
        saleLineItemEntity.setOrigReceiptType(saleLineItemType.getOrigReceiptType());
        saleLineItemEntity.setEntryMethod(saleLineItemType.getEntryMethod());
        saleLineItemEntity.setReturnReasonCode(saleLineItemType.getReturnReasonCode());
        saleLineItemEntity.setPriceOverride(mapBooleanToChar(saleLineItemType.isPriceOverride()));
        saleLineItemEntity.setPriceOverrideReasonCode(saleLineItemType.getPriceOverrideReasonCode());
        saleLineItemEntity.setTaxOverride(mapBooleanToChar(saleLineItemType.isTaxOverride()));
        saleLineItemEntity.setGiftCardRequestType(saleLineItemType.getGiftCardRequestType());
        saleLineItemEntity.setEncryptedGiftCardNumber(saleLineItemType.getEncryptedGiftCardNumber());
        saleLineItemEntity.setShippingIntrastatCode(saleLineItemType.getShippingIntrastatCode());
        saleLineItemEntity.setShippingMass(saleLineItemType.getShippingMass());
        saleLineItemEntity.setShippingCountryOfOrigin(saleLineItemType.getShippingCountryOfOrigin());
        saleLineItemEntity.setShippingFromCountry(saleLineItemType.getShippingFromCountry());
        saleLineItemEntity.setOriginateStockOutReasonCode(saleLineItemType.getOriginateStockOutReasonCode());
        saleLineItemEntity.setPriceTypeCode(saleLineItemType.getPriceTypeCode());
        saleLineItemEntity.setFulfillStoreID(saleLineItemType.getFulfillStoreID());
        saleLineItemEntity.setOmniCode(saleLineItemType.getOmniCode());
        saleLineItemEntity.setPickupStoreId(saleLineItemType.getPickupStoreId());
        saleLineItemEntity.setFulfillStoreAssociateId(saleLineItemType.getFulfillStoreAssociateId());
        saleLineItemEntity.setDemStoreId(saleLineItemType.getDemStoreId());
        saleLineItemEntity.setDemWorkstationId(saleLineItemType.getDemWorkstationId());
        saleLineItemEntity.setDemSequenceNumber(saleLineItemType.getDemSequenceNumber());
        saleLineItemEntity.setDemBusinessDate(saleLineItemType.getDemBusinessDate());
        taxLineItemMapper.mapToTaxLineItemEntity(saleLineItemType, map, taxLineItemEntityList);
        discountLineItemMapper.mapToDiscountLineItemEntity(saleLineItemType, map, discountLineItemEntityList);

        return saleLineItemEntity;
    }

    private char mapBooleanToChar(boolean variableToBeMapped) {
        return (variableToBeMapped ? CHARACTER_Y : CHARACTER_N);
    }

    private String mapOriginReceiptEntryMethod(String method) {
        return (isNotBlank(method) ? method : String.valueOf(CHARACTER_0));
    }
}
