package com.anf.salestrickle.etl.consumer.model.kafka;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

import javax.annotation.Generated;
import javax.validation.constraints.NotBlank;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "amount",
        "taxLinetype",
        "authority",
        "rate",
        "name"
})
@Generated("jsonschema2pojo")
public class TaxLineItemType {

    /**
     * Amount
     */
    @JsonProperty("amount")
    @JsonPropertyDescription("Amount")
    public double amount;
    /**
     * Type
     */
    @JsonProperty("taxLinetype")
    @JsonPropertyDescription("Type")
    public String taxLinetype;
    /**
     * Authority
     */
    @JsonProperty("authority")
    @JsonPropertyDescription("Authority")
    @NotBlank
    public String authority;
    /**
     * Rate
     */
    @JsonProperty("rate")
    @JsonPropertyDescription("Rate")
    public double rate;
    /**
     * Name
     */
    @JsonProperty("name")
    @JsonPropertyDescription("Name")
    public String name;

}
