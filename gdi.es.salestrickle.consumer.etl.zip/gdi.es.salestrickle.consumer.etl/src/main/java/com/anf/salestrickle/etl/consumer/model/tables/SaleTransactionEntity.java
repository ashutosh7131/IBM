package com.anf.salestrickle.etl.consumer.model.tables;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;


@Getter
@Setter
public class SaleTransactionEntity {

    private String storeId;
    private String workstationId;
    private String businessDate;
    private Double sequenceNumber;
    private String storeType;
    private String employeeSaleId;
    private String cashierId;
    private String authorizerId;
    private String saleType;
    private String reasonCode;
    private Date startTime;
    private Date endTime;
    private String taxExemptId;
    private String status;
    private Double filingCurrencyConversionFactor;
    private String filingCurrencyCode;
    private String origCurrencyCode;
    private double subtotalAmount;
    private double discountAmount;
    private double taxAmount;
    private Double totalAmount;
    private Double grandTotalAmount;
    private String originateEntryType;
    private String originateStoreId;
    private String originateWorkstationId;
    private String originateSequenceNumber;
    private String originateBusinessDate;
    private String originateEnteredBy;
    private String demandStore;
}
