package com.anf.salestrickle.etl.consumer.beans;

import com.anf.kafkaservicejsonschema.KafkaServiceJsonSchema;
import com.anf.kafkaservicejsonschema.models.Producer;
import com.anf.salestrickle.etl.consumer.config.AppKafkaConfig;
import com.anf.salestrickle.etl.consumer.model.kafka.SalesTransactions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class KafkaProducerBeans {

    private final KafkaServiceJsonSchema kafkaService;
    private final AppKafkaConfig appKafkaConfig;

    @Autowired
    public KafkaProducerBeans(KafkaServiceJsonSchema kafkaService, AppKafkaConfig appKafkaConfig) {
        this.kafkaService = kafkaService;
        this.appKafkaConfig = appKafkaConfig;
    }

    @Bean
    @Qualifier("DltProducer")
    public Producer<SalesTransactions> getDltProducer() throws Exception {
        return kafkaService.getProducer(this.appKafkaConfig.getDltTopic());
    }
    
    @Bean
    @Qualifier("Producer")
    public Producer<SalesTransactions> getProducer() throws Exception {
        return kafkaService.getProducer(this.appKafkaConfig.getTopic());
    }

}
