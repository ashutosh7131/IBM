package com.anf.salestrickle.etl.consumer.util.mappers;

import com.anf.salestrickle.etl.consumer.model.kafka.DiscountLineItemType;
import com.anf.salestrickle.etl.consumer.model.kafka.SaleLineItemType;
import com.anf.salestrickle.etl.consumer.model.tables.DiscountLineItemEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

import static com.anf.salestrickle.etl.consumer.data.Constants.*;

@Component
public class DiscountLineItemMapper {
    public void mapToDiscountLineItemEntity(SaleLineItemType saleLineItemType, Map<String, Object> map, List<DiscountLineItemEntity> discountLineItemEntityList) {
        List<DiscountLineItemType> discountLineItemTypeList = saleLineItemType.getDiscountLineItemList();
        if (null != discountLineItemTypeList && !discountLineItemTypeList.isEmpty()) {
            for (DiscountLineItemType discountLineItemType :
                    discountLineItemTypeList) {
                discountLineItemEntityList.add(mapToDiscountLineItemEntity(saleLineItemType, map, discountLineItemType));
            }
        }
    }

    private DiscountLineItemEntity mapToDiscountLineItemEntity(SaleLineItemType saleLineItemType, Map<String, Object> map, DiscountLineItemType discountLineItemType) {
        DiscountLineItemEntity discountLineItemEntity = new DiscountLineItemEntity();
        discountLineItemEntity.setStoreId((String) map.get(STORE_ID));
        discountLineItemEntity.setWorkstationId((String) map.get(WORKSTATION_ID));
        discountLineItemEntity.setBusinessDate((String) map.get(BUSINESS_DATE));
        discountLineItemEntity.setSequenceNumber(Double.valueOf((String) map.get(SEQUENCE_NUMBER)));
        discountLineItemEntity.setLineItemNumber(saleLineItemType.getLineItemNumber());
        discountLineItemEntity.setDiscountSequenceNumber(discountLineItemType.getDiscountSequenceNumber());
        discountLineItemEntity.setDiscounttype(mapDiscounttypeCoupon(discountLineItemType.getDiscounttype()));
        discountLineItemEntity.setAmount(discountLineItemType.getAmount());
        discountLineItemEntity.setPromotionId(Double.valueOf(discountLineItemType.getPromotionId()));
        discountLineItemEntity.setAaaGid(discountLineItemType.getAaaGid());
        discountLineItemEntity.setUniquePromotionCode(discountLineItemType.getUniquePromotionCode());
        return discountLineItemEntity;
    }

    private String mapDiscounttypeCoupon(DiscountLineItemType.Discounttype discounttype) {
        if (null != discounttype) {
            return discounttype.toString();
        }
        return DiscountLineItemType.Discounttype.UNKNOWN.toString();
    }
}
