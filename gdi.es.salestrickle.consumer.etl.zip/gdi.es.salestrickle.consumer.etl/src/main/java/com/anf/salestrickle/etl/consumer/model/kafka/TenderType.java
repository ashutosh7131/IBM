package com.anf.salestrickle.etl.consumer.model.kafka;

import com.fasterxml.jackson.annotation.*;
import lombok.Getter;
import lombok.Setter;

import javax.annotation.Generated;
import javax.validation.constraints.NotNull;
import java.util.HashMap;
import java.util.Map;


/**
 * Sales tender types
 */
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "lineItemNumber",
        "tenderNumber",
        "tenderAmount",
        "tenderType",
        "tenderTypeId",
        "tenderExchangeRate",
        "foreignTenderCurrencyCode",
        "foreignTenderAmount",
        "accountName",
        "cardAuthMethod",
        "cardAuthReturnCode",
        "cardEntryMode",
        "encryptedExpDate",
        "encryptedCardNumber",
        "hashedCardNumber",
        "maskedCardNumber",
        "encryptedCheckRoutingNumber",
        "encryptedCheckAccountNumber",
        "encryptionType",
        "refundRequired"
})
@Generated("jsonschema2pojo")
public class TenderType {

    /**
     * Line Item Number
     * (Required)
     */
    @JsonProperty("lineItemNumber")
    @JsonPropertyDescription("Line Item Number")
    @NotNull
    public Double lineItemNumber;
    /**
     * Tender Number
     */
    @JsonProperty("tenderNumber")
    @JsonPropertyDescription("Tender Number")
    @NotNull
    public double tenderNumber;
    /**
     * Tender Amount
     */
    @JsonProperty("tenderAmount")
    @JsonPropertyDescription("Tender Amount")
    public double tenderAmount;
    /**
     * Tender Type
     */
    @JsonProperty("tenderType")
    @JsonPropertyDescription("Tender Type")
    public String tenderType;
    /**
     * Tender Type Id
     */
    @JsonProperty("tenderTypeId")
    @JsonPropertyDescription("Tender Type Id")
    public String tenderTypeId;
    /**
     * Tender Exchange Rate
     */
    @JsonProperty("tenderExchangeRate")
    @JsonPropertyDescription("Tender Exchange Rate")
    public Double tenderExchangeRate;
    /**
     * Foreign Tender Currency Code
     */
    @JsonProperty("foreignTenderCurrencyCode")
    @JsonPropertyDescription("Foreign Tender Currency Code")
    public String foreignTenderCurrencyCode;
    /**
     * Foreign Tender Amount
     */
    @JsonProperty("foreignTenderAmount")
    @JsonPropertyDescription("Foreign Tender Amount")
    public Double foreignTenderAmount;
    /**
     * Account Name
     */
    @JsonProperty("accountName")
    @JsonPropertyDescription("Account Name")
    public String accountName;
    /**
     * Card Auth Method
     */
    @JsonProperty("cardAuthMethod")
    @JsonPropertyDescription("Card Auth Method")
    public String cardAuthMethod;
    /**
     * Card Auth Return Code
     */
    @JsonProperty("cardAuthReturnCode")
    @JsonPropertyDescription("Card Auth Return Code")
    public String cardAuthReturnCode;
    /**
     * Card Entry Mode
     */
    @JsonProperty("cardEntryMode")
    @JsonPropertyDescription("Card Entry Mode")
    public String cardEntryMode;
    /**
     * Encrypted Exp Date
     */
    @JsonProperty("encryptedExpDate")
    @JsonPropertyDescription("Encrypted Exp Date")
    public String encryptedExpDate;
    /**
     * Encrypted card Number
     */
    @JsonProperty("encryptedCardNumber")
    @JsonPropertyDescription("Encrypted card Number")
    public String encryptedCardNumber;
    /**
     * Hashed Card Number
     */
    @JsonProperty("hashedCardNumber")
    @JsonPropertyDescription("Hashed Card Number")
    public String hashedCardNumber;
    /**
     * Masked Card Number
     */
    @JsonProperty("maskedCardNumber")
    @JsonPropertyDescription("Masked Card Number")
    public String maskedCardNumber;
    /**
     * Encrypted Check Routing Number
     */
    @JsonProperty("encryptedCheckRoutingNumber")
    @JsonPropertyDescription("Encrypted Check Routing Number")
    public String encryptedCheckRoutingNumber;
    /**
     * Encrypted Check Account Number
     */
    @JsonProperty("encryptedCheckAccountNumber")
    @JsonPropertyDescription("Encrypted Check Account Number")
    public String encryptedCheckAccountNumber;
    /**
     * Encryption Type
     */
    @JsonProperty("encryptionType")
    @JsonPropertyDescription("Encryption Type")
    public EncryptionType encryptionType;
    /**
     * Refund Required Indicator
     */
    @JsonProperty("refundRequired")
    @JsonPropertyDescription("Refund Required Indicator")
    public boolean refundRequired;



    /**
     * Encryption Type
     */
    @Generated("jsonschema2pojo")
    public enum EncryptionType {

        EMPTY(""),
        C("C"),
        T("T"),
        G("G");
        private final static Map<String, EncryptionType> CONSTANTS = new HashMap<String, EncryptionType>();

        static {
            for (EncryptionType c : values()) {
                CONSTANTS.put(c.value, c);
            }
        }

        private final String value;

        EncryptionType(String value) {
            this.value = value;
        }

        @JsonCreator
        public static EncryptionType fromValue(String value) {
            EncryptionType constant = CONSTANTS.get(value);
            if (constant == null) {
                throw new IllegalArgumentException(value);
            } else {
                return constant;
            }
        }

        @Override
        public String toString() {
            return this.value;
        }

        @JsonValue
        public String value() {
            return this.value;
        }

    }

}
