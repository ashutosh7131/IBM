package com.anf.salestrickle.etl.consumer.util.mappers;

import com.anf.salestrickle.etl.consumer.model.kafka.SaleLineItemType;
import com.anf.salestrickle.etl.consumer.model.kafka.TaxLineItemType;
import com.anf.salestrickle.etl.consumer.model.tables.TaxLineItemEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

import static com.anf.salestrickle.etl.consumer.data.Constants.*;
import static java.lang.String.valueOf;

@Component
public class TaxLineItemMapper {

    public void mapToTaxLineItemEntity(SaleLineItemType saleLineItemType, Map<String, Object> map, List<TaxLineItemEntity> taxLineItemEntityList) {
        List<TaxLineItemType> taxLineItemTypeList = saleLineItemType.getTaxLineItemList();
        if (null != taxLineItemTypeList && !taxLineItemTypeList.isEmpty()) {
            for (TaxLineItemType taxLineItemType :
                    taxLineItemTypeList) {
                taxLineItemEntityList.add(mapToTaxLineItemEntity(saleLineItemType, map, taxLineItemType));
            }
        }
    }

    private TaxLineItemEntity mapToTaxLineItemEntity(SaleLineItemType saleLineItemType, Map<String, Object> map, TaxLineItemType taxLineItemType) {
        TaxLineItemEntity taxLineItemEntity = new TaxLineItemEntity();
        taxLineItemEntity.setStoreId((String) map.get(STORE_ID));
        taxLineItemEntity.setWorkstationId((String) map.get(WORKSTATION_ID));
        taxLineItemEntity.setBusinessDate((String) map.get(BUSINESS_DATE));
        taxLineItemEntity.setSequenceNumber((String) map.get(SEQUENCE_NUMBER));
        taxLineItemEntity.setLineItemNumber(saleLineItemType.getLineItemNumber());
        taxLineItemEntity.setTaxLinetype(taxLineItemType.getTaxLinetype());
        taxLineItemEntity.setAuthority(taxLineItemType.getAuthority());
        taxLineItemEntity.setAmount(valueOf(taxLineItemType.getAmount()));
        taxLineItemEntity.setRate(valueOf(taxLineItemType.getRate()));
        taxLineItemEntity.setName(taxLineItemType.getName());
        return taxLineItemEntity;
    }
}
